#ifndef STACK_H
#define STACK_H

#include "Array.h"

template <typename T>
class Stack
{
	public:
		Stack();
		Stack(int size);
		Stack(const Stack & copy);
		Stack<T> & operator=(const Stack & rhs);
		~Stack();
		
		void Push(T data);
		T Pop();
		T Peek();
		int Size();
		bool isEmpty();
		bool isFull();
		void setSize(int new_size);
	
	private:
		Array<T> m_stack;
		int m_size;
		int m_current;
};

template <typename T>
inline Stack<T>::Stack() : m_stack(), m_size(0), m_current(-1)
{
}

template<typename T>
inline Stack<T>::Stack(int size) : m_size(size), m_current(-1)
{
	m_stack.SetLength(size);
}

template<typename T>
inline Stack<T>::Stack(const Stack & copy) : m_stack(copy.m_stack),
	m_size(copy.m_size), m_current(-1)
{
}

template<typename T>
inline Stack<T> & Stack<T>::operator=(const Stack & rhs)
{
	if (this != &rhs)
	{
		m_stack = rhs.m_stack;
		m_size = rhs.m_size;
		m_current = rhs.m_current;
	}
	return *this;
}

template<typename T>
inline Stack<T>::~Stack()
{
	m_size = 0;
	m_current = -1;
}

template<typename T>
inline void Stack<T>::Push(T data)
{
	//Check for overflow
	if (m_current == m_size - 1)
		throw Exception("Overflow error");

	m_current++;
	m_stack[m_current] = data;
}

template<typename T>
inline T Stack<T>::Pop()
{
	//Check for underflow
	if (m_current < 0)
		throw Exception("Underflow Error\n");
	
	return m_stack[m_current--];
	
}

template<typename T>
inline T Stack<T>::Peek()
{
	if (isEmpty())
		throw Exception("Stack is empty, cannot get top element");
	return m_stack[m_current];
}

template<typename T>
inline int Stack<T>::Size()
{
	return m_current + 1;
}

template<typename T>
inline bool Stack<T>::isEmpty()
{
	bool empty = false;
	if (m_current == -1)
		empty = true;
	return empty;
}

template<typename T>
inline bool Stack<T>::isFull()
{
	bool full = false;
	if (m_current == m_size - 1)
		full = true;
	return false;
}

template<typename T>
inline void Stack<T>::setSize(int new_size)
{
	m_stack.SetLength(new_size);
}

#endif // !STACK_H