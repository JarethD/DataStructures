#include "BNode.h"
#include "Exception.h"
template <typename T>
class BSTree
{
	public:
		BSTree();
		BSTree(T data);
		BSTree(const BSTree<T> & copy);
		BSTree<T> & operator=(const BSTree<T> & rhs);
		~BSTree();

		void Insert(T data);
		void Insert(BNode<T> *& root, T data);

		void Delete(T data);
		BNode<T> * Delete(BNode<T> * root, T data);
		BNode<T> * largestNode(BNode<T> * root);
		void Purge(BNode<T> * root);
		int Height();
		int Height(BNode<T> * root);

		BNode<T> *& getRoot();
		void setRoot(BNode<T> * root);

	private:
		BNode<T> * Copy(BNode<T> * root);

		BNode<T> * m_root;
};

template<typename T>
inline BSTree<T>::BSTree() : m_root(nullptr)
{
}

template<typename T>
inline BSTree<T>::BSTree(T data)
{
	Insert(m_root, data);
}

template<typename T>
inline BSTree<T>::BSTree(const BSTree<T>& copy)// : m_root(copy.m_root)
{
	m_root = Copy(copy.m_root);
}

template<typename T>
inline BSTree<T>& BSTree<T>::operator=(const BSTree<T>& rhs)
{
	if (this != &rhs)
	{
		//delete current BSTree
		Purge(m_root);
		//deep copy contents from rhs to current
		m_root = Copy(rhs.m_root);
	}
	return *this;
}

template<typename T>
inline BSTree<T>::~BSTree()
{
	Purge(m_root);
}

template<typename T>
inline void BSTree<T>::Insert(T data)
{
	Insert(m_root, data);
}

/*
	Purpose: Insert an item into a Binary Search Tree recursivly

	Preconditions: 
		None
	Postconditons:
		data is added to the BSTree
*/
template<typename T>
inline void BSTree<T>::Insert(BNode<T> *& root, T data)
{
	if (root == nullptr)
	{
		BNode<T> * nn = new BNode<T>(data);
		root = nn;
	}
	else
	{
		if (root->m_data > data)
		{
			Insert(root->m_left, data);
		}
		else
		{
			Insert(root->m_right, data);
		}
	}
}


template<typename T>
inline void BSTree<T>::Delete(T data)
{
	m_root = Delete(m_root, data);
}

template<typename T>
inline BNode<T> * BSTree<T>::Delete(BNode<T>* root, T data)
{
	//if tree is empty
	if (root == nullptr)
	{
		//throw exception
	}
	//find node to delete
	if (data < root->getData()) //if the data is less than parents data go into the left subtree
		root->m_left = Delete(root->m_left, data);
	else if (data > root->getData()) // else data is greater than parents data, go into right subtree
		root->m_right = Delete(root->m_right, data);
	//node is found
	else
	{
		if (root->m_left == nullptr && root->m_right == nullptr)
		{
			delete root;
			root = nullptr;
		}
		else if (root->m_left == nullptr && root->m_right != nullptr)
		{
			BNode<T> * temp = root;
			root = root->m_right;
			delete temp;
		}
		else if(root->m_right == nullptr && root->m_left != nullptr)
		{
			BNode<T> * temp = root;
			root = root->m_left;
			delete temp;
		}
		else
		{
			
			BNode<T> * largest = largestNode(root->m_left);
			root->m_data = largest->m_data;
			root->m_left = Delete(root->m_left, largest->getData());
		}
	}
	return root;
}

template<typename T>
inline BNode<T> * BSTree<T>::largestNode(BNode<T>* root)
{
	if(root->m_right == nullptr)
		return root;
	return largestNode(root->m_right);
}

template<typename T>
inline void BSTree<T>::Purge(BNode<T> * root)
{
	//If the BSTree has items in it
	if (root != nullptr)
	{
		BNode<T> * cur = root;
		BNode<T> * left = root->m_left;
		BNode<T> * right = root->m_right;
		
		Purge(left);
		Purge(right);
		delete cur;
		
	}
}

template<typename T>
inline int BSTree<T>::Height()
{
	int tree_height = 0;
	tree_height = Height(m_root);
	return tree_height - 1;
}

template<typename T>
inline int BSTree<T>::Height(BNode<T> * root)
{
	int height = 0;
	int lHeight = 0;
	int rHeight = 0;

	if (root == nullptr)
		return 0;

	//check left child
	lHeight = Height(root->m_left);
	//check right child
	rHeight = Height(root->m_right);
		
	height = (rHeight > lHeight ? rHeight : lHeight);		
	
	return height + 1;
}

template<typename T>
inline BNode<T> *& BSTree<T>::getRoot()
{
	return m_root;
}

template<typename T>
inline void BSTree<T>::setRoot(BNode<T> * root)
{

}

template<typename T>
inline BNode<T>* BSTree<T>::Copy(BNode<T>* root)
{
	BNode<T> * tempNode = nullptr;
	if(root != nullptr)
	{
		tempNode = new BNode<T>(root->m_data);
		tempNode->m_left = Copy(root->getLeft());
		tempNode->m_right = Copy(root->getRight());
	}
	return tempNode;
}