/*
	Author: Jareth Dodson
	Date created: 2-14-19
	Filename: BNode.h

	Class: BNode

	Purpose: Hold a piece of data for a binary search tree

	Manager Functions:
		BNode()
			Create an empty binary search tree
		BNode(const BNode<T> & copy)

*/

#ifndef BNODE_H
#define BNODE_H

template <typename T>
class BSTree;

template <typename T>
class BNode
{
	template <typename T>
	friend class BSTree;

	public:
		BNode();
		BNode(T data);
		BNode(const BNode<T> & copy);
		BNode<T> & operator=(const BNode<T> & rhs);
		~BNode();

		BNode<T> * getLeft() const;
		BNode<T> * getRight() const;
		T & getData();
	private:
		BNode<T> * m_left;
		BNode<T> * m_right;
		T m_data;
};

template<typename T>
inline BNode<T>::BNode()
{
}

template<typename T>
inline BNode<T>::BNode(T data) : m_data(data), m_left(nullptr), m_right(nullptr)
{
}

template<typename T>
inline BNode<T>::BNode(const BNode<T>& copy) : m_data(copy.m_data), m_left(copy.m_left), m_right(copy.m_right)
{
}

template<typename T>
inline BNode<T>& BNode<T>::operator=(const BNode<T>& rhs)
{
	if (this != &rhs)
	{
		m_data = rhs.m_data;
		m_left = rhs.m_left;
		m_right = rhs.m_right;
	}
	return *this;
}



template<typename T>
inline BNode<T>::~BNode()
{
	m_left = nullptr;
	m_right = nullptr;
}

template<typename T>
inline BNode<T>* BNode<T>::getLeft() const
{
	return m_left;
}

template<typename T>
inline BNode<T>* BNode<T>::getRight() const
{
	return m_right;
}

template<typename T>
inline T & BNode<T>::getData()
{
	return m_data;
}


#endif //!BNODE_H