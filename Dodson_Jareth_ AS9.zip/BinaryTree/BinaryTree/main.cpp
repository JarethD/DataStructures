/*
	Author: Jareth Dodson
	
	Filename: main.cpp

	Purpose: This program will test and use a binary search tree

	Problems:
		No visit function
		Breadth first does not work

*/
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#include <iostream>
#include "BSTree.h"
#include "Queue.h"

using std::cout;

//In-order traversal
template <typename T>
void Inorder(BNode<T> * root);
template <typename T>
void Preorder(BNode<T> * root);
template <typename T>
void Postorder(BNode<T> * root);
template <typename T>
void BreadthFirst(BSTree<T> tree);

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	//CTOR
	BSTree<int> tree;
	//Inserts
	tree.Insert(5);
	tree.Insert(4);
	tree.Insert(6);
	tree.Insert(10);
	tree.Insert(7);
	cout << tree.Height() << endl;
	Inorder(tree.getRoot());
	//Test delete
	tree.Delete(7);
	BSTree<int> tree2;
	//op=
	tree2 = tree;
	cout << '\n';
	//Inorder
	Inorder(tree2.getRoot());
	cout << '\n';
	//Preorder
	Preorder(tree2.getRoot());
	cout << '\n';
	//Postorder
	Postorder(tree2.getRoot());
	cout << '\n';
	//copy ctor
	BSTree<int> tree3 = tree2;
	Inorder(tree3.getRoot());

	return 0;
}

template<typename T>
void Inorder(BNode<T> * root)
{
	if (root != nullptr)
	{
		if(root->getLeft() != nullptr)
			Inorder(root->getLeft());
		cout << root->getData() << " ";
		if(root->getRight() != nullptr)
			Inorder(root->getRight());
	}
}

template<typename T>
void Preorder(BNode<T>* root)
{
	if (root != nullptr)
	{
		cout << root->getData() << " ";
		Preorder(root->getLeft());
		Preorder(root->getRight());
	}
}

template<typename T>
void Postorder(BNode<T>* root)
{
	if (root != nullptr)
	{
		Postorder(root->getLeft());
		Postorder(root->getRight());
		cout << root->getData() << " ";
	}
}

//template<typename T>
//void BreadthFirst(BSTree<T> tree)
//{
//	if (tree.getRoot() == nullptr)
//		return;
//
//	BNode<T> current = *tree.getRoot();
//	//create Queue bfqueue
//	
//	Queue<BNode<T>> tempQueue;
//
//	tempQueue.Enqueue(current);
//
//	while (&current != nullptr)
//	{
//		while (!tempQueue.isEmpty())
//		{
//			current = tempQueue.Dequeue();
//		}
//		cout << current->getData();
//		if (current.getLeft() != nullptr)
//		{
//			tempQueue.Enqueue(tree.getRoot()->getLeft());
//		}
//		if (current.getRight() != nullptr)
//		{
//			tempQueue.Enqueue(tree.getRoot()->getRight());
//		}
//
//		else
//		{
//			&current = nullptr;
//		}
//	}
//}