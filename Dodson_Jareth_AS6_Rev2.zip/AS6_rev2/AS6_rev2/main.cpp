/*
	Author: Jareth Dodson
	File Name: main.cpp
	Assignment: Assignment 6: Stack using linked List

	Purpose: Test stack implementation.
	
*/

#include "Stack.h"

bool CTOR_Test();
bool CopyCTOR_Test();
bool opEquals_Test();
bool Push_Test();
bool Pop_Test();
bool PopEmpty_Test();

int main()
{
	if (CTOR_Test())
		cout << "Ctor Passed" << endl;
	else
		cout << "CTOR failed" << endl;

	if (CopyCTOR_Test())
		cout << "Copy ctor passed" << endl;
	else
		cout << "Copy ctor failed" << endl;

	if (opEquals_Test())
		cout << "op = test passed" << endl;
	else
		cout << "op = test failed" << endl;

	if (Push_Test())
		cout << "Push test passed" << endl;
	else
		cout << "Push test failed" << endl;


	if (Pop_Test())
		cout << "Pop test passed" << endl;
	else
		cout << "Pop test failed" << endl;


	if (PopEmpty_Test())
		cout << "Pop empty test passed" << endl;
	else
		cout << "Pop empty test failed" << endl;
}

bool CTOR_Test()
{
	bool pass = false;

	{
		Stack<int> Lstack;
		if (Lstack.isEmpty() && Lstack.Size() == 0)
			pass = true;
	}

	return pass;
}

bool CopyCTOR_Test()
{
	bool pass = false;

	{
		Stack<int> Lstack;
		Stack<int> Lstack2 = Lstack;
		if (Lstack2.isEmpty() && Lstack2.Size() == 0)
			pass = true;
	}

	return pass;
}

bool opEquals_Test()
{
	bool pass = false;

	{
		Stack<int> Lstack;
		Stack<int> Lstack2;
		Lstack2 = Lstack;
		if (Lstack2.isEmpty() && Lstack2.Size() == 0)
			pass = true;
	}

	return pass;
}

bool Push_Test()
{
	bool pass = false;

	{
		Stack<int> Lstack;
		for (int i = 0; i < 10; ++i)
			Lstack.Push(i);

		if (!Lstack.isEmpty() && Lstack.Size() == 10)
			pass = true;
	}

	return pass;
}

bool Pop_Test()
{
	bool pass = false;

	{
		Stack<int> Lstack;
		for (int i = 0; i < 10; ++i)
			Lstack.Push(i);
		Lstack.Pop();
		Lstack.Pop();
		Lstack.Pop();
		if (Lstack.Size() == 7 && Lstack.Peek() == 6)
			pass = true;
	}

	return pass;
}

bool PopEmpty_Test()
{
	bool pass = false;

	{
		Stack<int> Lstack;
		try
		{
			Lstack.Pop();
		}
		catch (Exception &exception)
		{
			pass = true;
		}
	}
	return pass;
}
