#ifndef STACK_H
#define STACK_H
#include "List.h"

template <typename T>
class Stack
{
public:
	Stack();
	Stack(const Stack & copy);
	Stack<T> & operator=(const Stack & rhs);
	~Stack();

	void Push(T data);
	T Pop();
	T Peek();
	int Size();
	bool isEmpty();

private:
	List<T> m_stack;
	int m_size;
	int m_current;
};

#endif //STACK_H

template<typename T>
inline Stack<T>::Stack() : m_size(0)
{
}

template<typename T>
inline Stack<T>::Stack(const Stack & copy) : m_stack(copy.m_stack), m_size(copy.m_size)
{
}

template<typename T>
inline Stack<T>& Stack<T>::operator=(const Stack & rhs)
{
	if (this != &rhs)
	{
		m_stack = rhs.m_stack;
		m_size = rhs.m_size;
	}
	return *this;
}

template<typename T>
inline Stack<T>::~Stack()
{
	m_size = 0;
}

template<typename T>
inline void Stack<T>::Push(T data)
{
	m_stack.Prepend(data);
	m_size++;
}

template<typename T>
inline T Stack<T>::Pop()
{
	if (isEmpty() && m_size == 0)
		throw Exception("Underflow error");
	T temp = m_stack.First();
	m_stack.Extract(temp);
	m_size--;
	return temp;
}

template<typename T>
inline T Stack<T>::Peek()
{
	return m_stack.First();
}

template<typename T>
inline int Stack<T>::Size()
{
	return m_size;
}

template<typename T>
inline bool Stack<T>::isEmpty()
{
	return m_stack.IsEmpty();
}
