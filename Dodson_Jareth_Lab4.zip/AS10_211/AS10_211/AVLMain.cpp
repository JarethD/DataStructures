#include "AVLTree.h"
#include <iostream>

using std::cout;

template <typename T>
void Preorder(AVLNode<T> * root);

int main()
{
	//test ctor and insert
	AVLTree<int> tree;
	tree.Insert(10);
	tree.Insert(8);
	tree.Insert(9);
	tree.Insert(11);
	tree.Insert(12);
	tree.Insert(13);
	// 10 8 9 11 12 13
	Preorder(tree.getRoot());
	cout << '\n';
	//test delete
	tree.Delete(9);
	Preorder(tree.getRoot());
	cout << '\n';
	////copy ctor
	AVLTree<int> tree2 = tree;
	Preorder(tree2.getRoot());
	cout << '\n';
	AVLTree<int> tree3;
	//op=
	tree3 = tree;
	Preorder(tree3.getRoot());
}

template<typename T>
void Preorder(AVLNode<T> * root)
{
	if (root != nullptr)
	{
		cout << root->getData() << " ";
		Preorder(root->getLeft());
		Preorder(root->getRight());
	}

}