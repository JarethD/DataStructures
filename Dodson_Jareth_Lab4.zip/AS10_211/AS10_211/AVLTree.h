/*
	Class: AVLTree
	Author: Jareth Dodson

	Purpose: Using the AVLNode class, create an AVL tree that can insert and delete items

	Manager Functions:
		AVLTree()
		AVLTree(const AVLTree<T> & copy)
		operator=(const AVLTree<T> & rhs)
		~AVLTree()

	Methods:
		AVLTree<T> * copy(AVLTree<T> * root)
			copies the contents from root and copies it to m_root
		Insert(T data)
			Calls 2 arg insert
		Insert(AVLTree *& root, T data)
			inserts data into the tree and balances tree if needed
		Delete(T data)
			calls 2 arg delete
		AVLTree * Delete(AVLTree<T> * root, T data)
			delete data, if present, and rebalances if needed
		AVLTree<T> * largestNode(AVLTree<T> * root)
			find the largest node in the tree
		Purge(AVLTree<T> * root)
			purges list
		RRrotation(AVLNode<T> * root)
			performs an RR rotation on root
		LLrotation(AVLNode<T> * root)
			performs an LL rotation on root
		int BFactor(AVLTree<T> * root)
			returns the balance factor of the root
		int Height(AVLTree<T> * root)
			returns the height of the root
		int findMax(int lhs, int rhs);
			returns the max data
		AVLTree<T>* getRoot()
			returns root of tree		
		
		*/

#ifndef AVLTREE_H
#define AVLTREE_H

#include "AVLNode.h"

template <typename T>
class AVLTree
{
	public:
		AVLTree();
		AVLTree(const AVLTree<T> & copy);
		AVLTree<T> & operator=(const AVLTree<T> & rhs);
		~AVLTree();

		AVLNode<T> * Copy(AVLNode<T> * root);

		void Insert(T data);
		void Insert(AVLNode<T> *& root, T data);
		void Delete(T data);
		AVLNode<T> * Delete(AVLNode<T> * root, T data);
		AVLNode<T> * largestNode(AVLNode<T> * root);

		void Purge(AVLNode<T> * root);

		AVLNode<T> * RRrotation(AVLNode<T> * root);
		AVLNode<T> * LLrotation(AVLNode<T> * root);

		int BFactor(AVLNode<T> * root);
		int Height(AVLNode<T> * root);
		T findMax(int lhs, int rhs);

		AVLNode<T> * getRoot();

	private:
		AVLNode<T> * m_root;
};


#endif // !AVLTREE_H

template<typename T>
inline AVLTree<T>::AVLTree() : m_root(nullptr)
{
}

template<typename T>
inline AVLTree<T>::AVLTree(const AVLTree<T>& copy)
{
	//shallow copy
	m_root = Copy(copy.m_root);
}

template<typename T>
inline AVLTree<T>& AVLTree<T>::operator=(const AVLTree<T>& rhs)
{
	if (this != &rhs)
	{
		//deep copy
		Purge(m_root);
		m_root = Copy(rhs.m_root);
	}
	return *this;
}

template<typename T>
inline AVLTree<T>::~AVLTree()
{
	//purge list and set to default
	Purge(m_root);
}

template<typename T>
inline AVLNode<T> *  AVLTree<T>::Copy(AVLNode<T>* root)
{
	AVLNode<T> * tempNode = nullptr;
	if (root != nullptr)
	{
		tempNode = new AVLNode<T>(root->getData());
		tempNode->m_left = Copy(root->getLeft());
		tempNode->m_right = Copy(root->getRight());
	}
	return tempNode;
}

template<typename T>
inline void AVLTree<T>::Insert(T data)
{
	//call 2 arg insert
	Insert(m_root, data);
}

template<typename T>
inline void AVLTree<T>::Insert(AVLNode<T>*& root, T data)
{
	if (root == nullptr)
	{
		root = new AVLNode<T>(data);
	}
	//left subtree
	else if(data < root->getData())
	{
		Insert(root->m_left, data);
		if (BFactor(root) - 1 == -2)	
		{
			if (data < root->m_left->m_data)
				root = LLrotation(root);
			else
			{
				root = LLrotation(root->m_left);
				root = RRrotation(root);
			}
		}
	}
	//right subtree
	else if (data > root->getData())
	{
		Insert(root->m_right, data);
		if (BFactor(root) - 1 == 2)
		{
			if (data > root->m_left->m_data)
				root = RRrotation(root);
			else
			{
				root = RRrotation(root->m_right);
				root = LLrotation(root);
			}
		}
	}
	//set balance factor of root
	root->m_balanceFactor = BFactor(root) - 1;
}

template<typename T>
inline void AVLTree<T>::Delete(T data)
{
	m_root = Delete(m_root, data);
}

template<typename T>
inline AVLNode<T> * AVLTree<T>::Delete(AVLNode<T>* root, T data)
{
	if (root == nullptr)
	{
		throw Exception("Cannot delete from empty tree");
	}
	//find data
	//if data is less than root, add to left subtree of root
	if (data < root->getData())
		root->m_left = Delete(root->m_left, data);
	//else add to right subtree of root
	else if (data > root->getData())
		root->m_right = Delete(root->m_right, data);
	//else node is 
	else
	{
		//if node is a leaf node
		if (root->m_left == nullptr && root->m_right == nullptr)
		{
			delete root;
			root = nullptr;
		}
		//left child is empty and right isn't
		else if (root->m_left == nullptr && root->m_right != nullptr)
		{
			AVLNode<T> * temp = root;
			root = root->m_right;
			delete temp;
		}
		//right child is empty and right isn't
		else if (root->m_right == nullptr && root->m_left != nullptr)
		{
			AVLNode<T> * temp = root;
			root = root->m_left;
			delete temp;
		}
		//both children have data
		else
		{
			AVLNode<T> * largest = largestNode(root->m_left);
			root->m_data = largest->m_data;
			root->m_left = Delete(root->m_left, largest->getData());
		}
	}
	//rebalance the tree is root is not nullptr
	if (root != nullptr)
	{
		//rebalance left subtree
		if (BFactor(root) - 1 == 2)
		{
			//if roots left subtree balance factor is greater than 0, perform LLrotation
			if (BFactor(root->m_left) - 1 >= 0)
				root = LLrotation(root);
			else if(BFactor(root->m_right) - 1 < 0)
			{
				root = LLrotation(root->m_left);
				root = RRrotation(root);
			}
			
		}
		//rebalance right subtree
		if (BFactor(root) - 1 == -2)
		{
			//if roots right subtree balance factor is less than or equal to 0, perform RRrotation 
			if (BFactor(root->m_right) - 1 <= 0)
				root = RRrotation(root);
			else if(BFactor(root->m_left) - 1 > 0)
			{
				root = RRrotation(root->m_right);
				root = LLrotation(root);
			}
			
		}
	}
	return root;
}

template<typename T>
inline AVLNode<T>* AVLTree<T>::largestNode(AVLNode<T>* root)
{
	//if right subtree is empty, in largest node
	if (root->m_right == nullptr)
		return root;
	return largestNode(root->m_right);
}

template<typename T>
inline void AVLTree<T>::Purge(AVLNode<T> * root)
{
	if (root != nullptr)
	{
		AVLNode<T> * current = root;
		AVLNode<T> * left = root->getLeft();
		AVLNode<T> * right = root->getRight();

		Purge(left);
		Purge(right);
		delete current;
	}
	root = nullptr;
}


template<typename T>
inline AVLNode<T>* AVLTree<T>::RRrotation(AVLNode<T>* root)
{
	AVLNode<T> * temp = nullptr;
	if (root != nullptr)
	{
		//temp equals roots right subtree
		temp = root->getRight();
		//set t2 to other side
		root->setRight(temp->getLeft());
		//make old root temps left subtree
		temp->setLeft(root);
	}
	return temp;
}

template<typename T>
inline AVLNode<T> * AVLTree<T>::LLrotation(AVLNode<T>* root)
{
	AVLNode<T> * temp = nullptr;
	if (root != nullptr)
	{
		//temp equals roots left subtree
		temp = root->getLeft(); 
		//set t2 to other side
		root->setLeft(temp->getRight());
		//make old root temps right sub tree
		temp->setRight(root);
	}
	return temp;
}

template<typename T>
inline int AVLTree<T>::BFactor(AVLNode<T> * root)
{
	//height of left subtree
	int left_height = Height(root->m_left);
	//height of right subtree
	int right_height = Height(root->m_right);
	//balance factor of root
	int balance_factor = left_height - right_height;
	return balance_factor + 1;
}

template<typename T>
inline int AVLTree<T>::Height(AVLNode<T>* root)
{
	int height = 0;
	if (root != nullptr)
	{
		int right_height = Height(root->getRight());
		int left_height = Height(root->getLeft());
		height = (right_height > left_height ? right_height : left_height);
	}
	return height + 1;
}

template<typename T>
inline T AVLTree<T>::findMax(int lhs, int rhs)
{
	return (lhs > rhs ? lhs : rhs);
}

template<typename T>
inline AVLNode<T>* AVLTree<T>::getRoot()
{
	return m_root;
}