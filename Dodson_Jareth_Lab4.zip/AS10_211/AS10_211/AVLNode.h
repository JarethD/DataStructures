/*
	Class : AVLNode
	Author: Jareth Dodson
	
	Purpose: The purpose of this class is to hold data for an AVL tree

	Manager Functions:
		AVLNode()
			Default node with no data and left and right set to nullptr
		AVLNode(T data)
			Default node with T data with left and right set to nullptr
		AVLNode(const AVLNode<T> & copy)
			Copy Ctor
		operator=(cont AVLNode & rhs)
		~AVLNode()

	Methods:
		getData()
			returns data of node
		getRight()
			returns the right subtree of node
		getLeft()
			returns the left subtree of node
		setData(T data)
			sets m_data to data
		setRight(AVLNode<T> * right)
			sets m_right to right
		setLeft(AVLNode<T> * left)
			sets m_left to left

		*/

#ifndef AVLNODE_H
#define AVLNODE_H

#include "Exception.h"

template <typename T>
class AVLTree;

template <typename T>
class AVLNode
{
	template <typename T>
	friend class AVLTree;

	public:
		AVLNode();
		AVLNode(T data);
		AVLNode(const AVLNode<T> & copy);
		AVLNode<T> & operator=(const AVLNode<T> & rhs);
		~AVLNode();

		//Getters
		int getBalanceFactor();
		T getData();
		AVLNode<T> * getRight();
		AVLNode<T> * getLeft();

		//Setters
		void setBalanceFactor(int balanceFactor);
		void setData(T data);
		void setRight(AVLNode<T> * right);
		void setLeft(AVLNode<T> * left);

	private:
		T m_data;
		AVLNode<T> * m_right;
		AVLNode<T> * m_left;
		int m_balanceFactor;
};
#endif // !AVLNODE_H

template<typename T>
inline AVLNode<T>::AVLNode() : m_left(nullptr), m_right(nullptr), m_balanceFactor(0)
{
}

template<typename T>
inline AVLNode<T>::AVLNode(T data) : m_data(data), m_balanceFactor(0), 
	m_left(nullptr), m_right(nullptr)
{
}

template<typename T>
inline AVLNode<T>::AVLNode(const AVLNode<T>& copy) : m_right(copy.m_right), m_left(copy.m_left),
	m_balanceFactor(copy.m_balanceFactor), m_data(copy.m_data)
{
}

template<typename T>
inline AVLNode<T>& AVLNode<T>::operator=(const AVLNode<T>& rhs)
{
	if (this != &rhs)
	{
		m_data = rhs.m_data;
		m_balanceFactor = rhs.m_balanceFactor;
		m_left = rhs.m_left;
		m_right = rhs.m_right;
	}
	return *this;
}

template<typename T>
inline AVLNode<T>::~AVLNode()
{
	m_left = nullptr;
	m_right = nullptr;
	m_balanceFactor = 0;
}

template<typename T>
inline int AVLNode<T>::getBalanceFactor()
{
	return m_balanceFactor;
}

template<typename T>
inline T AVLNode<T>::getData()
{
	return m_data;
}

template<typename T>
inline AVLNode<T>* AVLNode<T>::getRight()
{
	return m_right;
}

template<typename T>
inline AVLNode<T>* AVLNode<T>::getLeft()
{
	return m_left;
}

template<typename T>
inline void AVLNode<T>::setBalanceFactor(int balanceFactor)
{
	m_balanceFactor = balanceFactor;
}

template<typename T>
inline void AVLNode<T>::setData(T data)
{
	m_data = data;
}

template<typename T>
inline void AVLNode<T>::setRight(AVLNode<T>* right)
{
	m_right = right;
}

template<typename T>
inline void AVLNode<T>::setLeft(AVLNode<T>* left)
{
	m_left = left;
}