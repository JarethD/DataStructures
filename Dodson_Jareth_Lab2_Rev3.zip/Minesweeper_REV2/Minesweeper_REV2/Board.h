#pragma once
#ifndef BOARD_H
#define BOARD_H
#include "Array2D.h"
#include "Cell.h"
#include <stdlib.h>
#include <time.h>
#include <iomanip>
using std::setw;

/*
	Class Board

	Purpose: This class will create a board of size x and y for minesweeper

	MODIFICATIONS:
		Added Y and X axis labels and numbering to board display
		Added functionality to play again if you win or lose

	Manager Functions:
		Board();
		Board(char input)
		Board(const Board & copy)
		~Board();
		Board & operator =(const Board & rhs)

	Methods:
		DisplayBoard()
		Play Move(int xcoord, int ycoord, bool mark);
		Count Bombs(int xcoord, int ycoord)
		FloodUncover(int xcoord, int ycoord)
		UncoverNumbers(int xcoord, int ycoord)
		PlayerWon()
		GetGameover()

	Getters:
		GetBoardRows()
		GetBoardColumns()
*/

class Board
{
public:
	Board();
	Board(char input);
	Board(const Board & copy);
	Board & operator =(const Board & rhs);
	~Board();
	void DisplayBoard();
	void PlayMove(int xcoord, int ycoord, bool mark);
	int CountBombs(int xcoord, int ycoord);

	void FloodUncover(int xcoord, int ycoord);
	void UncoverNumbers(int xcoord, int ycoord);
	int PlayerWon();
	int GetBoardRows();
	int GetBoardColumns();
	int GetGameOver();

private:
	Array2D<Cell> m_board;
	int m_rows;
	int m_columns;
	int m_numOfMines;
	char m_input;
	int m_gameOver;
};
#endif 