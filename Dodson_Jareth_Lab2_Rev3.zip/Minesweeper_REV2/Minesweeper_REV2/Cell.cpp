#include "Cell.h"

/*
	Purpose: Create a cell object with deafult values
*/
Cell::Cell() : m_bomb(false), m_covered(true), m_numOfBombs(0), m_marked(false)
{
}

/*
	Purpose: Copy the data of a cell object to another cell

	Precondition:
		Copy - A cell Object

	Postcondition:
		Modififes the current data members of the object
*/
Cell::Cell(const Cell & copy) :
	m_bomb(copy.m_bomb), m_covered(copy.m_covered),
	m_numOfBombs(copy.m_numOfBombs), m_marked(copy.m_marked)
{
}

/*
	Purpose: Override the operator = for a cell object

	Precondition:
		rhs - A cell object

	Postcondition:
		modifies the left hand side data members
*/
Cell & Cell::operator=(const Cell & rhs)
{
	if (this != &rhs)
	{
		m_bomb = rhs.m_bomb;
		m_covered = rhs.m_covered;
		m_numOfBombs = rhs.m_numOfBombs;
		m_marked = rhs.m_marked;
	}
	return *this;
}
/*
	Purpose: Cell Destructor

	Preconditon
		Cell Object

	Postconditon
		Modifies Cell object to default values
*/
Cell::~Cell()
{
	//RESET TO DEFAULT
	m_bomb = false;
	m_covered = true;
	m_marked = false;
	m_numOfBombs = 0;
}

/*
	Purpose: Display the cell

	Preconditon
		Pre-existing cell object

	Postcondtion
		Displays cell
*/
void Cell::DisplayCell()
{
	if (m_covered) // ascii 254 // block
		cout << char(254);
	else if (!m_covered)
		if (m_marked)
		{
			cout << "?";
		}
		else if (m_bomb)
		{
			cout << "*";
		}
		else
		{
			if (m_numOfBombs > 0)
			{
				cout << m_numOfBombs;
			}
			else
			{
				cout << " ";
				//Uncover all cells around and flood fill algorithm
			}
		}
}

/*
	Purpose: Set cell object bomb variable

	Precondtion:
		bomb - either true or false

	Postcondition:
		m_bomb changes to state of bomb
*/
void Cell::SetBomb(bool bomb)
{
	m_bomb = bomb;
}

/*
	Purpose: Set cell object cover status

	Precondtion:
		cover - either true or false

	Postcondtion:
		m_covered changes to state of cover
*/
void Cell::SetCover(bool cover)
{
	m_covered = cover;
}

/*
	Purpose: Set number of bombs around the cell

	Precondtion:
		numOfBombs - integer value greater than 0

	Postcondtion:
		m_numOfBombs changes to value of numOfbombs

*/
void Cell::SetNumOfBombs(int numbOfBombs)
{
	m_numOfBombs += numbOfBombs;
}

/*
	Purpose: Set cell object mark status

	Precondtion:
		mark - either true or false

	Postcondtion:
		m_marked changes to state of mark
*/
void Cell::SetMark(bool mark)
{
	m_marked = mark;
}

/*
	Purpose: Get status of m_bomb

	Precondtion:
		None

	Postcondtion:
		returns value of m_bomb
*/
bool Cell::GetBomb()
{
	return m_bomb;
}

/*
	Purpose: Get status of m_covered

	Precondtion:
		None

	Postcondtion:
		returns value m_covered
*/
bool Cell::GetCover()
{
	return m_covered;
}

/*
	Purpose: Get value of m_numOfBombs

	Precondtion:
		None

	Postcondtion:
		return value of m_numOfBombs
*/
int Cell::GetNumOfBombs()
{
	return m_numOfBombs;
}

/*
	Purpose: return status of m_marked

	Precondtion:
		None

	Postcondtion:
		return status of m_marked
*/
bool Cell::GetMark()
{
	return m_marked;
}
