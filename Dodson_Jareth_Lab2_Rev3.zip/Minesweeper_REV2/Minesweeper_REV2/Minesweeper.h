#ifndef MINESWEEPER_H
#define MINESWEEPER_H
#include <Windows.h>
#include <iostream>
#include "Board.h"

using std::cout;
using std::cin;
using std::endl;

/*
	Class Minesweeper

	Purpose: This class creates the game minesweeper

	Manager Functions:
		Minesweeper()
		Minesweeper(const Minesweeper & copy)
		Minesweeper & operator=(const Minesweeper & rhs)
		~Minesweeper()

	Methods:
		StartGame()
*/

class Minesweeper
{
public:
	Minesweeper();
	Minesweeper(const Minesweeper & copy);
	Minesweeper & operator=(const Minesweeper & rhs);
	~Minesweeper();

	void StartGame();
	bool IsInputValid();


private:
	Board m_board;
	char m_input;
};

#endif