//Jareth Dodson
//Doubly linked list
//Node.h
#pragma once
#ifndef NODE_H
#define NODE_H

template <typename T>
class List;

template <typename T>
class Node
{
	template <typename T>
	friend class List;

public:
	Node();
	Node(T data);
	Node(const Node<T> & copy);
	Node<T> & operator=(const Node<T> & rhs);
	~Node();

	T GetData() const;
	Node<T> * GetPrevious() const;
	Node<T> * GetNext() const;

private:
	T m_data;
	Node<T> * m_next;
	Node<T> * m_prev;
};

template <typename T>
Node<T>::Node() : m_next(nullptr), m_prev(nullptr), m_data()
{
}

template<typename T>
inline Node<T>::Node(T data) : m_next(nullptr), m_prev(nullptr), m_data(data)
{
}

template<typename T>
inline Node<T>::Node(const Node<T>& copy) : m_next(copy.m_next), m_prev(copy.m_prev), m_data(copy.m_data)
{
}

template<typename T>
inline Node<T>& Node<T>::operator=(const Node<T>& rhs)
{
	if (this != &rhs)
	{
		m_data = rhs.m_data;
		m_next = rhs.m_next;
		m_prev = rhs.m_prev;
	}
	return *this;
}

template <typename T>
Node<T>::~Node()
{
	m_next = nullptr;
	m_prev = nullptr;
}

template<typename T>
inline T Node<T>::GetData() const
{
	return m_data;
}

template<typename T>
inline Node<T>* Node<T>::GetPrevious() const
{
	return m_prev;
}

template<typename T>
inline Node<T>* Node<T>::GetNext() const
{
	return m_next;
}

#endif // !NODE_H