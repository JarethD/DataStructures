#ifndef GRAPH_H
#define GRAPH_H
#include <iostream>

#include <iterator>
#include "Stack.h"
#include "Arc.h"
#include "Vertex.h"
using std::iterator;
using std::cout;

template <typename V, typename E>
class Graph
{
public:
	Graph();
	~Graph();
	Graph(const Graph<V, E> & copy);
	Graph<V, E> & operator=(const Graph<V, E> & rhs);

	void InsertVertex(V data);
	void DeleteVertex(V data);
	void InsertArc(V from, V to, E edge, int weight);
	void DeleteArc(V from, V to, E edge);

	void DepthFirst(V data);

	bool isEmpty();
	void DisplayGraph();

	list<Vertex<V, E>> getVertices();

private:
	list<Vertex<V, E>> m_vertices;

};

#endif // !GRAPH_H

template<typename V, typename E>
inline Graph<V, E>::Graph() : m_vertices()
{
}

template<typename V, typename E>
inline Graph<V, E>::~Graph()
{
}

template<typename V, typename E>
inline Graph<V, E>::Graph(const Graph<V, E>& copy) : m_vertices(copy.m_vertices)
{
}

template<typename V, typename E>
inline Graph<V, E>& Graph<V, E>::operator=(const Graph<V, E>& rhs)
{
	if (this != &rhs)
	{
		m_vertices = rhs.m_vertices;
	}
	return *this;
}

template<typename V, typename E>
inline void Graph<V, E>::InsertVertex(V data)
{
	m_vertices.push_back(data);
}

template<typename V, typename E>
inline void Graph<V, E>::DeleteVertex(V data)
{
	//find vertex, go delete vertex and remove from all arcs and vertex list if  conneccted
	typename list<Vertex<V, E>>::iterator iter = m_vertices.begin();
	while ((*iter).getData() != data)
		iter++;
	//list is empty
	if (iter == m_vertices.end())
		return;
	iter = m_vertices.erase(iter);
	iter--;
	(*iter).getEdges().remove(data);
	iter++;
	iter++;
	(*iter).getEdges().erase(data);
}

template<typename V, typename E>
inline void Graph<V, E>::InsertArc(V from, V to, E edge, int weight)
{
	typename list<Vertex<V, E>>::iterator iter = m_vertices.begin();
	////iterate thru until you find to or from, from should be first
	while ((*iter).getData() != from)
	{
		iter++;
	}
	if (iter == m_vertices.end())
		return;
	Vertex<V, E> * dest = &(*iter);
	Arc<V, E> temparc(dest, edge, weight);

	(*iter).add_arc(temparc);
	iter = m_vertices.begin();
	while ((*iter).getData() != to)
		iter++;

	dest = &(*iter);

	Arc<V, E> temparc2(dest, edge, weight);

	(*iter).add_arc(temparc2);
}

template<typename V, typename E>
inline void Graph<V, E>::DeleteArc(V from, V to, E edge)
{
	typename list<Vertex<V, E>>::iterator iter = m_vertices.begin();
	while ((*iter).getData() != from)
		iter++;
	(*iter).delete_arc(edge);
	iter = m_vertices.begin();
	while ((*iter).getData() != to)
		iter++;
	(*iter).delete_arc(edge);

}

template<typename V, typename E>
inline void Graph<V, E>::DepthFirst(V data)
{
	if (isEmpty())
		return;
	typename list<Vertex<V, E>>::iterator iter = m_vertices.begin();
	for (iter = m_vertices.begin(); iter != m_vertices.end(); iter++)
	{
		(*iter).setProcess(false);
	}
	Stack<Vertex<V, E>> stack;
	iter = m_vertices.begin();
	(*iter).setProcess(true);
	stack.Push((*iter));

	//visit(stack.Push);
	while (!stack.isEmpty())
	{
		Vertex<V, E> tempdata = stack.Pop();
		//visit
		cout << tempdata.getData() << " - ";

		if (!tempdata.getProcess())
		{
			//cout << tempdata.getData() << " ";
			tempdata.setProcess(true);
		}

		for (iter = m_vertices.begin(); iter != m_vertices.end(); iter++)
		{
			if (!(*iter).getProcess())
			{
				stack.Push((*iter));
				(*iter).setProcess(true);
			}
		}
	}

}

template<typename V, typename E>
inline bool Graph<V, E>::isEmpty()
{
	bool empty = false;
	if (m_vertices.empty())
		empty = true;
	return empty;
}

template<typename V, typename E>
inline void Graph<V, E>::DisplayGraph()
{
	typename list<Vertex<V, E>>::iterator iter = m_vertices.begin();
	while (iter);
	{
		cout << (*iter).getData() << " ";
		iter++;
	}
}

template<typename V, typename E>
inline list<Vertex<V, E>> Graph<V, E>::getVertices()
{
	return m_vertices;
}
