/*
	Author: Jareth Dodson
	File name: main.cpp

	Lab 4 - Late - Dijkstras

	Purpose: The purpose of this lab was to use our graph class
		to implement dijkstras shortest path algorithm

	Not sure if Dijkstra's work

*/

#include <string>
#include "Graph.h"
#include <vector>
#include <iostream>
#include <fstream>

using std::ifstream;
using std::cin;
using std::vector;
using std::string;
using std::getline;

template <typename V, typename E>
void visit(Vertex<V, E> *vertex);


//Does not work
template <typename V, typename E>
void dijkstra(Graph<V, E> & graph, V from, V to)
{
	list<Vertex<V, E>> templist = graph.getVertices();


	int * predecessors = new int[templist.size()];
	int * dist = new int[templist.size()];

	
	//set all values to -1
	for (int i = 0; i < templist.size(); ++i)
	{
		dist[i] = -1;
		predecessors[i] = -1;
	}
	//distance from self
	dist[0] = 0;
	int i = 0;

	//for the entire graph
	while(!templist.empty())
	{
		//Not sure why this won't work
		//iterator to the list<Arc<V, E>> in vertex.h
		Vertex<V, E> temp = templist.front();
		templist.pop_front();
		typename list<Arc<V, E>>::iterator arciter = temp.getEdges().begin();
		
		//loop for entire list
		for (; arciter != temp.getEdges().end(); ++arciter)
			//if the weight of arciter is less than the current or is empty
			if ((*arciter).getWeight() < dist[i] || dist[i] == -1)
				//add the lowest weight to the distance array
				dist[i] = (*arciter).getWeight();
		if (temp.getData() == to)
			break;
		++i;
	}

	//reconstruct path

	delete[] dist;
	delete[] predecessors;
}


//template <typename V, typename E>
int main()
{
	string dest1;
	string dest2;
	cout << "Enter Start: "; 
	cin >> dest1;
	cout << "Ender Destination: ";
	cin >> dest2;
	Graph<string, string> g1;
	
	ifstream ifile;

	ifile.open("lab5.txt");
	while (ifile)
	{
		string temp;
		string temp2;
		string temp3;
		string w;
		int weight;
		getline(ifile, temp, ',');
		if (temp == "")
			break;
		g1.InsertVertex(temp);
		getline(ifile, temp2, ',');
		g1.InsertVertex(temp2);
		getline(ifile, temp3, ',');
		getline(ifile, w);
		weight = stoi(w);
		g1.InsertArc(temp, temp2, temp3, weight);
	}
	ifile.close();
	dijkstra(g1, dest1, dest2);

	return 0;
}

template<typename V, typename E>
void visit(Vertex<V, E>* vertex)
{
	cout << vertex->getData() << " ";
}
