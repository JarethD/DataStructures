#pragma once
#ifndef VERTEX_H
#define VERTEX_H
#include <list>
#include "Arc.h"
using std::list;

template <typename V, typename E>
class Arc;

template <typename V, typename E>
class Vertex
{
public:
	Vertex();
	Vertex(V data);
	Vertex(const Vertex<V, E> & copy);
	Vertex<V, E>& operator=(const Vertex<V, E> & rhs);

	Vertex(Vertex<V, E> && copy);
	Vertex<V, E> & operator=(Vertex<V, E> && rhs) const;

	list<Arc<V, E>> & getEdges();
	V getData();
	void add_arc(Arc<V, E> arc);
	void delete_arc(E data);

	void setProcess(bool processed);
	bool getProcess();

	bool operator==(const Vertex<V, E> & rhs);
	bool operator!=(const Vertex<V, E> & rhs);

private:

	V m_vdata;
	bool m_processed;
	list<Arc<V, E>> m_edges;
};

template<typename V, typename E>
inline Vertex<V, E>::Vertex() : m_processed(false)
{
}

template<typename V, typename E>
inline Vertex<V, E>::Vertex(V data) : m_vdata(data), m_processed(false)
{
}

template<typename V, typename E>
inline Vertex<V, E>::Vertex(const Vertex<V, E>& copy) : m_edges(copy.m_edges), m_vdata(copy.m_vdata), m_processed(copy.m_processed)
{
}

template<typename V, typename E>
inline Vertex<V, E>& Vertex<V, E>::operator=(const Vertex<V, E>& rhs)
{
	if (this != &rhs)
	{
		m_vdata = rhs.m_vdata;
		m_edges = rhs.m_edges;
		m_processed = rhs.m_processed;
	}
	return *this;
}

template<typename V, typename E>
inline Vertex<V, E>::Vertex(Vertex<V, E>&& copy) : m_edges(copy.m_edges), m_vdata(copy.m_vdata), m_processed(copy.m_processed)
{
}

template<typename V, typename E>
inline Vertex<V, E>& Vertex<V, E>::operator=(Vertex<V, E>&& rhs) const
{
	if (this != &rhs)
	{
		m_vdata = rhs.m_vdata;
		m_edges = rhs.m_edges;
		m_processed = rhs.m_processed;
	}
	return *this;
}

template<typename V, typename E>
inline list<Arc<V, E>> & Vertex<V, E>::getEdges()
{
	return m_edges;
}

template<typename V, typename E>
inline V Vertex<V, E>::getData()
{
	return m_vdata;
}

template<typename V, typename E>
inline void Vertex<V, E>::add_arc(Arc<V, E> arc)
{
	m_edges.push_back(arc);
}

template<typename V, typename E>
inline void Vertex<V, E>::delete_arc(E data)
{
	typename list<Arc<V, E>>::iterator iter = m_edges.begin();
	while ((*iter).getData() != data)
		iter++;
	m_edges.remove((*iter));
}

template<typename V, typename E>
inline void Vertex<V, E>::setProcess(bool processed)
{
	m_processed = processed;
}

template<typename V, typename E>
inline bool Vertex<V, E>::getProcess()
{
	return m_processed;
}

template<typename V, typename E>
inline bool Vertex<V, E>::operator==(const Vertex<V, E> & rhs)
{
	bool equal = false;
	if (m_edges == rhs.m_edges)
		if (m_processed == rhs.m_processed)
			if (m_vdata == rhs.m_vdata)
				equal = true;
	return equal;
}

template<typename V, typename E>
inline bool Vertex<V, E>::operator!=(const Vertex<V, E>& rhs)
{
	bool equal = true;
	if ((*this == rhs))
		equal = false;
	return equal;
}

//template<typename V, typename E>
//inline bool Vertex<V, E>::operator==(const Vertex<V, E>& lhs, const Vertex<V, E>& rhs)
//{
//	bool equal = false;
//	if()
//	return equal;
//}

#endif //!VERTEX_H
