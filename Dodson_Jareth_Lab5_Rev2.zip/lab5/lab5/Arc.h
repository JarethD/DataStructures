#pragma once
#ifndef ARC_H
#define ARC_H

#include "Vertex.h"

template <typename V, typename E>
class Vertex;

template <typename V, typename E>
class Arc
{
public:
	Arc();
	Arc(Vertex<V, E> * destination, E data, const int weight);
	Arc(const Arc<V, E> & copy);
	Arc(Arc< V, E > && copy);

	Arc<V, E> & operator=(const Arc<V, E> & rhs);
	Arc<V, E> & operator=(Arc<V, E> && rhs);
	bool operator==(const Arc<V, E> & rhs) const;

	Vertex<V, E> * getDestination();
	int getWeight() const;
	E getData();


private:
	E m_data;
	int m_weight;
	Vertex<V, E> * m_destination;

};

#endif // !ARC_H

template<typename V, typename E>
inline Vertex<V, E>* Arc<V, E>::getDestination()
{
	return m_destination;
}

template<typename V, typename E>
inline int Arc<V, E>::getWeight() const
{
	return m_weight;
}

template<typename V, typename E>
inline E Arc<V, E>::getData()
{
	return m_data;
}

template<typename V, typename E>
inline Arc<V, E>::Arc() : m_destination(nullptr), m_weight(0)
{
}

template<typename V, typename E>
inline Arc<V, E>::Arc(Vertex<V, E>* destination, E data, const int weight) :
	m_data(data), m_weight(weight), m_destination(destination)
{

}

template<typename V, typename E>
inline Arc<V, E>::Arc(const Arc<V, E>& copy) : m_data(copy.m_data), m_weight(copy.m_weight), m_destination(copy.m_destination)
{
}

template<typename V, typename E>
inline Arc<V, E>::Arc(Arc<V, E>&& copy) : m_data(copy.m_data), m_destination(copy.m_destination), m_weight(copy.m_weight)
{
}

template<typename V, typename E>
inline Arc<V, E>& Arc<V, E>::operator=(const Arc<V, E>& rhs)
{
	if (this != &rhs)
	{
		m_data = rhs.m_data;
		m_weight = rhs.m_weight;
		//not a deep copy
		m_destination = rhs.m_destination;
	}
	return *this;
}

template<typename V, typename E>
inline Arc<V, E>& Arc<V, E>::operator=(Arc<V, E>&& rhs)
{
	if (this != &rhs)
	{
		m_data = rhs.m_data;
		m_weight = rhs.m_weight;
		//not a deep copy
		m_destination = rhs.m_destination;
	}
	return *this;
}

template<typename V, typename E>
inline bool Arc<V, E>::operator==(const Arc<V, E>& rhs) const
{
	bool pass = false;
	if (m_data == rhs.m_data)
		if (m_weight == rhs.m_weight)
			if (m_destination == rhs.m_destination)
				pass = true;
	return pass;
}
