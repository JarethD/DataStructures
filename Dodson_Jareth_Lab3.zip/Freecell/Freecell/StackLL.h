/*
	Class: StackLL

	Purpose: Create a stack using a doubly linked list class as it's data structure

	Manager functions:
		StackLL()
			Creates an empty stack with a default size of 0
		StackLL(const StackLL & copy)
			Shallow copies contents from copy
		operator(const StackLL & rhs)
			Deep copies contents from rhs)
		~StackLL()
			Stack DTOR	
				Sets values back to default
	Methods:
		Push(T data)
			Add item data to the top of the stack
		Pop()
			Takes the top item off of the stack and returns it
		Peek()
			Returns the item at the top of the stack 
		Size()
			Returns the size of the stack
		isEmpty()
			Checks if the stack is empty or not
*/
#ifndef StackLL_H
#define StackLL_H
#include "List.h"

template <typename T>
class StackLL
{
public:
	StackLL();
	StackLL(const StackLL & copy);
	StackLL<T> & operator=(const StackLL & rhs);
	~StackLL();

	void Push(T data);
	T Pop();
	T Peek();
	int Size();
	bool isEmpty();

private:
	List<T> m_stack;
	int m_size;
	int m_current;
};

#endif //StackLL_H

template<typename T>
inline StackLL<T>::StackLL() : m_size(0)
{
}

template<typename T>
inline StackLL<T>::StackLL(const StackLL & copy) : m_stack(copy.m_stack), m_size(copy.m_size)
{
}

template<typename T>
inline StackLL<T>& StackLL<T>::operator=(const StackLL & rhs)
{
	if (this != &rhs)
	{
		m_stack = rhs.m_stack;
		m_size = rhs.m_size;
	}
	return *this;
}

template<typename T>
inline StackLL<T>::~StackLL()
{
	m_size = 0;
}

template<typename T>
inline void StackLL<T>::Push(T data)
{
	m_stack.Prepend(data);
	m_size++;
}

template<typename T>
inline T StackLL<T>::Pop()
{
	if (isEmpty())
		throw Exception("Underflow error");
	T temp = m_stack.First();
	m_stack.Extract(temp);
	m_size--;
	return temp;
}

template<typename T>
inline T StackLL<T>::Peek()
{
	return m_stack.First();
}

template<typename T>
inline int StackLL<T>::Size()
{
	return m_size;
}

template<typename T>
inline bool StackLL<T>::isEmpty()
{
	return m_stack.IsEmpty();
}
