#include "Card.h"
char suitsDisplay[5] = {'X', 'C', 'D', 'S', 'H' };
char ranksDisplay[14] = { 'X', '1','2','3','4','5','6','7','8','9','T','J','Q','K' };

/*
	Purpose: Set the card object with default values

	Precondtion:
		Card must be called
	Postcondtion:
		Creates a card object
*/
Card::Card() : m_rank(def), m_suit(X)
{
}
/*
	Purpose: Sets the card to the value the user has given

	Precondtion:
		Card must be called
	Postcondtion:
		Creates a card with a rank and suit of the users choice
*/
Card::Card(SUITS suit, RANKS rank) : m_suit(suit), m_rank(rank)
{
}
/*
	Purpose: Sets the card to the value the user has given

	Precondtion:
		Card must be called
	Postcondtion:
		Creates a card with a rank and suit of the users choice
*/
Card::Card(int suit, int rank) : m_suit(SUITS(suit)), m_rank(RANKS(rank))
{
}
/*
	Purpose: Shallow copies cotents from copy

	Precondtion:
		Must have a lhs
	Postcondtion:
		left hand side is equal to copy
*/
Card::Card(const Card & copy) : m_suit(copy.m_suit), m_rank(copy.m_rank)
{
}
/*
	Purpose: override the = operator

	Precondtion:
		Must have a lhs
	Postcondtion:
		lhs is equal to rhs
*/
Card & Card::operator=(const Card & rhs)
{
	if (this != &rhs)
	{
		m_suit = rhs.m_suit;
		m_rank = rhs.m_rank;
	}
	return *this;
}
/*
	Purpose: override the == operator

	Precondtion:	
		Must have 2 objects
	Postcondtion:
		returns whether the objects are the same
*/
bool Card::operator==(const Card & rhs)
{
	bool pass = false;
	if (m_rank == rhs.m_rank && m_suit == rhs.m_suit)
		pass = true;
	return pass;
}
/*
	Purpose: override the != operator

	Precondtion:
		Must have 2 objects
	Postcondtion:
		returns whether the objects are not the same
*/
bool Card::operator!=(const Card & rhs)
{
	bool pass = false;
	if (m_rank != rhs.m_rank && m_suit != rhs.m_suit)
		pass = true;
	return pass;
}
/*
	Purpose: Card DTOR
		
	Precondtion:	
		Must have a card already created
	Postcondtion:
		Values are set back to default and card is destroyed
*/
Card::~Card()
{
	m_rank = def;
	m_suit = X;
}
/*
	Purpose: returns the suit of current card

	Precondtion:
		Must have a card already created
	Postcondtion:
		Returns the suit of card
*/
const SUITS Card::getSuit()
{
	return m_suit;
}
/*
	Purpose: returns the rank of current card

	Precondtion:
		Must have a card already created
	Postcondtion:
		Returns the rank of card
*/
const RANKS Card::getRank()
{
	return m_rank;
}
/*
	Purpose: Sets the card to value the user has chosen

	Precondtion:
		Must have a card already created
	Postcondtion:
		Card is modified with values from user
*/
void Card::SetCard(int suit,int rank)
{
	m_suit = SUITS(suit);
	m_rank = RANKS(rank);
}
/*
	Purpose: Display the suit and rank of card

	Precondtion:
		Card must be created previously
	Postcondtion:
		Display the rank and suit of card

		//Display Rank followed by Suit
		//1 of C
*/
void Card::Display()
{
	cout << ranksDisplay[m_rank] << " of " << suitsDisplay[m_suit];
}
