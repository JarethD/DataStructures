/*
	Class: Exception

	Purpose: To replicate and exception for errors

	Manager functions:
		Exception()
			Creates an exception with a default value of nullptr
		Exception(const char * msg)
			Creates an exception with a message of msg
		Exception(const Exception & copy)
			Shallow copies data from copy
		operator=(const Exception & rhs)
			Deep copies data from rhs)
		operator<<(ostream & stream , const Exception & except)
			overrides the << operator to display the exception message
		~Exception()
			Reset values to nullptr

	Methods:
		getMessage() const
			Returns the exception message
		setMessage(char * msg)
			Sets the message to msg
*/
#pragma once
#ifndef EXCEPTION_H
#define EXCEPTION_H

#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <cstring>

using namespace std;

class Exception
{
public:
	Exception();
	Exception(const char  * msg);
	Exception(const Exception & copy);

	Exception & operator=(const Exception & rhs);
	friend ostream & operator<<(ostream & stream, const Exception & except);

	~Exception();

	const char * getMessage() const;
	void setMessage(char * msg);

private:
	char * m_msg;

};
#endif // !EXCEPTION_H