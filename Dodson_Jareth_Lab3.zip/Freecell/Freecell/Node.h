/*
	Class: Node

	Purpose: To hold data for a linked list

	Manager functions:
		Node()
			Creates a Node holding no data with m_next and m_prev set to nullptr
		Node(T data)
			Creates a Node holding data of type T with m_next and m_prev set to nullptr
		Node(const Node<T> & copy)
			Shallow copies the data of copy
		operator=(const Node<T> & rhs)
			Deep copies the data from rhs
		~Node()
			Node DTOR
				Resets all values back to default
	Methods:
		GetData() const
			Returns the data the Node is holding
		GetPrevious() const
			Returns the previous item in the list that the node holds
		GetNext() const
			Returns the next item in the list that the node holds 

*/
#pragma once
#ifndef NODE_H
#define NODE_H

template <typename T>
class List;

template <typename T>
class Node
{
	template <typename T>
	friend class List;

public:
	Node();
	Node(T data);
	Node(const Node<T> & copy);
	Node<T> & operator=(const Node<T> & rhs);
	~Node();

	T GetData() const;
	Node<T> * GetPrevious() const;
	Node<T> * GetNext() const;

private:
	T m_data;
	Node<T> * m_next;
	Node<T> * m_prev;
};

template <typename T>
Node<T>::Node() : m_next(nullptr), m_prev(nullptr), m_data()
{
}

template<typename T>
inline Node<T>::Node(T data) : m_next(nullptr), m_prev(nullptr), m_data(data)
{
}

template<typename T>
inline Node<T>::Node(const Node<T>& copy) : m_next(copy.m_next), m_prev(copy.m_prev), m_data(copy.m_data)
{
}

template<typename T>
inline Node<T>& Node<T>::operator=(const Node<T>& rhs)
{
	if (this != &rhs)
	{
		m_data = rhs.m_data;
		m_next = rhs.m_next;
		m_prev = rhs.m_prev;
	}
	return *this;
}

template <typename T>
Node<T>::~Node()
{
	m_next = nullptr;
	m_prev = nullptr;
}

template<typename T>
inline T Node<T>::GetData() const
{
	return m_data;
}

template<typename T>
inline Node<T>* Node<T>::GetPrevious() const
{
	return m_prev;
}

template<typename T>
inline Node<T>* Node<T>::GetNext() const
{
	return m_next;
}

#endif // !NODE_H