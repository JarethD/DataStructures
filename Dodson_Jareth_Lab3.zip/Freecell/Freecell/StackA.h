/*
	Class: StackA

	Purpose: Create a stack using an Array as its data structure

	Manager functions:
		StackA()
			Creates a stack with a default size of 0
		Stack(int size)
			Creates a stack with the size given
				Should be greater than 0
		StackA(const StackA & copy)
			Shallow copies the contents from copy
		operator=(const StackA & rhs)
			Deep copies the contents from rhs
	Methods:
		Push(T data)
			Adds the item data to the top of the stack
		Pop()
			Takes the top item off of the stack
*/
#ifndef StackA_H
#define StackA_H

#include "Array.h"

template <typename T>
class StackA
{
public:
	StackA();
	StackA(int size);
	StackA(const StackA & copy);
	StackA<T> & operator=(const StackA & rhs);
	~StackA();

	void Push(T data);
	T Pop();
	T Peek();
	int Size();
	bool isEmpty();
	bool isFull();
	void setSize(int new_size);

private:
	Array<T> m_stack;
	int m_size;
	int m_current;
};

template <typename T>
inline StackA<T>::StackA() : m_stack(), m_size(0), m_current(-1)
{
}

template<typename T>
inline StackA<T>::StackA(int size) : m_size(size), m_current(-1)
{
	m_stack.SetLength(size);
}

template<typename T>
inline StackA<T>::StackA(const StackA & copy) : m_stack(copy.m_stack),
m_size(copy.m_size), m_current(-1)
{
}

template<typename T>
inline StackA<T> & StackA<T>::operator=(const StackA & rhs)
{
	if (this != &rhs)
	{
		m_stack = rhs.m_stack;
		m_size = rhs.m_size;
		m_current = rhs.m_current;
	}
	return *this;
}

template<typename T>
inline StackA<T>::~StackA()
{
	m_size = 0;
	m_current = -1;
}

template<typename T>
inline void StackA<T>::Push(T data)
{
	//Check for overflow
	if (m_current == m_size - 1 && m_current!= -1)
		throw Exception("Overflow error");

	m_current++;
	m_stack[m_current] = data;
}

template<typename T>
inline T StackA<T>::Pop()
{
	//Check for underflow
	if (m_current < 0)
		throw Exception("Underflow Error\n");

	return m_stack[m_current--];

}

template<typename T>
inline T StackA<T>::Peek()
{
	if (isEmpty())
		throw Exception("StackA is empty, cannot get top element");
	return m_stack[m_current];
}

template<typename T>
inline int StackA<T>::Size()
{
	return m_current + 1;
}

template<typename T>
inline bool StackA<T>::isEmpty()
{
	bool empty = false;
	if (m_current == -1)
		empty = true;
	return empty;
}

template<typename T>
inline bool StackA<T>::isFull()
{
	bool full = false;
	if (m_current == m_size - 1)
		full = true;
	return false;
}

template<typename T>
inline void StackA<T>::setSize(int new_size)
{
	m_stack.SetLength(new_size);
}

#endif // !StackA_H