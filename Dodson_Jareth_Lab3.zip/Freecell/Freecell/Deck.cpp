#include "Deck.h"
/*
	Purpose: Create a deck object containing 52 cards containing 4 suits and 13 ranks

	Precondtion:
		Deck class must me initailized

	Postcondtion:
		m_deck will be modified to a default state
		m_current will be set to default value
*/
Deck::Deck() : m_deck(52), m_current(0)
{
	Card temp;
	int card_position = 0;
	for (int i = 0; i < 4; ++i)
	{
		for (int x = 0; x < 13; ++x)
		{
			temp.SetCard(i + 1, x + 1);
			m_deck[card_position++] = temp;
		}
	}
}

Deck::Deck(const Deck & copy) :m_deck(copy.m_deck), m_current(copy.m_current)
{
}
/*
	Purpose: overload the operator = sign for the deck class

	Precondtion:
		Two pre-existing deck objects
	
	Postcondtion:
		left hand side will equal right hand side
*/
Deck & Deck::operator=(const Deck & rhs)
{
	if (this != &rhs)
	{
		m_deck = rhs.m_deck;
		m_current = rhs.m_current;
	}
	return *this;
}

Deck::~Deck()
{
	m_current = 0;
}
/*
	Purpose: Deal the top card on the deck

	Precondition:
		None

	Postcondition:
		returns card at the currnet position in the deck
		Increments m_current
*/
Card Deck::DealTop()
{
	if (m_current == 52)
		m_current = 0;
	return m_deck[m_current++];
}

/*
	Purpose: Return the top card of the deck to see

	Precondtion:
		Existing Deck object

	Postcondtion:
		returns m_deck at the current position
*/
Card Deck::ShowTop()
{
	return m_deck[m_current];
}
/*
	Purpose: Display all 52 cards of the deck

	Precondition:
		Existing Deck Object

	Postcondtion:
		Prints the cards to the command line
*/
void Deck::DisplayDeck()
{
	for (int i = 0; i < 52; ++i)
	{
		m_deck[i].Display();
		cout << "\n";
	}
}
/*
	Purpose: Shuffle the deck 7 times for an efficient shuffle
	
	Precondition:
		None
	Postcondition
		Deck will be modified into a random arrangment
*/
void Deck::Shuffle()
{
	srand(time(NULL));
	int randomCard = rand() % 52;
	//Efficient number of shuffles if 7
	// Multiply it by 3 for a more efficient shuffle
	Card temp;
	for (int i = 0; i < 7 * 3; ++i)
	{
		for (int x = 0; x < 52; ++x)
		{
			//Take random spot in deck
			randomCard = rand() % 52;
			//set temp card to card to switch with temp
			temp = m_deck[x];
			//random card to new position
			m_deck[x] = m_deck[randomCard];
			//replace random  card with swapped card
			m_deck[randomCard] = temp;
		}
	}
	
}
