#include "Freecell.h"

int main()
{
	Freecell Game;
	Game.PlayGame();
	return 0;
}