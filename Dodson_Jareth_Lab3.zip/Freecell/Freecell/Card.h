/*
	Class: Card

	Purpose: Create an interpretaion of a card with a rank and a suit

	Manager Functions:
		Card()
			Default is set Suit X and rank def
		Card(SUITS suit, RANKS rank)
			Creates a card with a SUITS of suit and RANKS of rank
		Card(int suit, int rank)
			Creates a card with a SUITS at suit in enum SUITS 
				and with a RANKS of rank in enum RANKS
		Card(const Card & copy)
			Shallow copies contents from copy
		operator=(const Card * rhs)
			Deep copies contents from rhs
		~Card()
	Methods:
		operator==(const Card & rhs);
		operator!=(const Card & rhs);
		getSuit()
		getRank()
		SetCard(int suit, int rank)
		Display()
*/
#ifndef CARD_H
#define CARD_H

#include <iostream>
#include <string>
using std::string;
using std::cout;
using std::endl;

enum SUITS { X = 0, C, D, S, H };
enum RANKS { def = 0, One, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King };

class Card
{

	public:
		Card();
		Card(SUITS suit, RANKS rank);
		Card(int suit, int rank);
		Card(const Card & copy);
		Card & operator=(const Card & rhs);
		bool operator==(const Card & rhs);
		bool operator!=(const Card & rhs);
		~Card();
		const SUITS getSuit();
		const RANKS getRank();
		void SetCard(int suit,int rank);
		void Display();

	private:
		SUITS m_suit;
		RANKS m_rank;
};

#endif //CARD_H