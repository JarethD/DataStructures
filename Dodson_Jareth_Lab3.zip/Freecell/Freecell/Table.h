/*
	Class: Table

	Purpose: Create a freecell table/board with all cards on board

	Manager functions:
		Table()
			Creates a table object with all 52 cards randomized on the table
		Table(const Table & copy)
			Shallow copies contents of copy
		operator=(const Table & rhs)
			Deep copies contents from rhs
		~Table()
			Table DTOR
				Set values to default
	Methods:
		DisplayBoard()
			Display the Board
				Starting with freecells, homecells, then the play area
		NumOfCardsMovable()
			Returns the amount of cards possible to move at once
		GetPlaycell()
			Returns the playcell for modification
		GetHomecell()
			Returns the homecell for modification
		GetFreecell()
			Returns teh freecell for modification
*/

#ifndef TABLE_H
#define TABLE_H
#include <Windows.h>
#include <conio.h>
#include <iomanip>
#include "Array.h"
#include "StackA.h"
#include "StackLL.h"
#include "Deck.h"

using std::setw;

class Table
{
	public:
		Table();
		Table(const Table & copy);
		Table & operator=(const Table & rhs);
		~Table();

		void DisplayTable();
		int NumOfCardsMovable();
		Array<StackLL<Card>> & GetPlaycell();
		Array<StackA<Card>> & GetHomecell();
		Array<Card> & GetFreecell();
	private:
		//freecells
		Array<Card> m_freecell;
		//homecells
		Array<StackA<Card>> m_homecell;
		//playcells
		Array<StackLL<Card>> m_playcell;
		//Game Deck
		Deck m_gamedeck;

};

#endif //!Table_H