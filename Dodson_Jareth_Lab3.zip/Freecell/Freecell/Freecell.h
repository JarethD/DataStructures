/*
	Class: Freecell

	Purpose: Creates a game of freecell

	Manager functions:
		Freecell()
			Creates a game of freecell with m_gameover set to false and a randomized table
		Freecell(const Freecell & copy)
			Shallow copies the data from copy
		operator=(const Freecell & rhs)
			Deep copies the data from rhs
		~Freecell()
			Freecell DTOR
				Set values back to default values

	Methods:
		Intro()
			Displays an intro to the user
		PlayGame()
			Starts the game of Freecell
		PlayMove(char input)
			Play the move that the user that specified
		isGameWon()
			returns a bool whether the game is won or not
*/
#ifndef FREECELL_H
#define FREECELL_H

#include "Table.h"

class Freecell
{
	public:
		Freecell();
		Freecell(const Freecell & copy);
		Freecell & operator=(const Freecell & rhs);
		~Freecell();

		void Intro();
		void PlayGame();
		void PlayMove(char input);
		//void GetMove(int * x_coord, int * y_coord);
		bool isGameWon();

	private:
		Table m_freecellTable;
		bool m_gameover;
};

#endif // !FREECELL_H