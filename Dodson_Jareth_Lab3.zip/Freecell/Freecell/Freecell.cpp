#include "Freecell.h"
/*
	Purpose: Instaniate a Freecell game object

	Precondtion:
		Must create a freecell object

	Postcondition:
		Freecell object created
*/
Freecell::Freecell() : m_freecellTable(), m_gameover(false)
{
}
/*
	Purpose: Shallow copy contents from copy to left hand side

	Precondition:
		Freecell object previously instantiated

	Postcondtion:
		left hand side data members are modified to equal copy
*/
Freecell::Freecell(const Freecell & copy) :m_freecellTable(copy.m_freecellTable), m_gameover(copy.m_gameover)
{
}

Freecell & Freecell::operator=(const Freecell & rhs)
{
	if (this != &rhs)
	{
		m_freecellTable = rhs.m_freecellTable;
		m_gameover = rhs.m_gameover;
	}
	return *this;
}

Freecell::~Freecell()
{
	m_gameover = false;
}
/*
	Purpose: Display an intro to user prompting them the name of the game, who made it,
		and the class it is for. It also tells the player what the area are how you can move from or to them

	Precondtion:
		Existing Freecell object
	
	Postcondition:
		Displays the intro to the console
*/
void Freecell::Intro()
{
	cout <<  "\tFreecell" << endl;
	cout <<  "\tMade by Jareth Dodson" << endl;
	cout <<  "\tData Structures CST 211" << endl;
	cout << "\n\n" << setw(10) << "The top left 4 cells are the freecells, top right 4 cells are the homecells" << endl;
	cout << "To play the game you choose which are you would like to modify" << endl;
	cout << "You can only move cards to a homcell" << endl;
	cout << "You can move cards to and from the freecells and \n can move as many cards as you want if possible in the play area" << endl;
	cout << "T is for Ten, J is for Jack, Q is for Queen and K is for King for the card ranks" << endl;
	cout << '\n';
	cout << "Press enter to continue to game" << endl;
}

/*
	Purpose: Play the game of freecell, asking which cell you would like too modify

	Precondtion
		Existing Freecell object

	Postcondtion:
		Game is started
*/
void Freecell::PlayGame()
{
	int x = 0;
	int y = 0;
	char input = '\0';
	Intro();
	cin.get();
	while (!m_gameover)
	{
		m_freecellTable.DisplayTable();
		cout << "Which cell would you like to modify, homecell(h), freecell(f), or playcell(p) : ";
		cin >> input;
		PlayMove(input);
		if (isGameWon())
			m_gameover = true;
	}
	cout << "Congrats, You won!" << endl;
}

/*
	Purpose: The purpose of this functions is too play the move the user has chosen

	Precondition:
		a char input either 'p' , 'h', or 'f'

	Postcondition
		Move is played and board is updated
*/
void Freecell::PlayMove(char input)
{
	//if input is homecell
	if (input == 'h' || input == 'H')
	{
		int cardToMove = 0;
		int hCellModify = 0;
		cout << "Which homecell would you like to modify? (1-4) : ";
		cin >> hCellModify;
		//if hCellModify is in bounds
		if (hCellModify > 0 && hCellModify <= 4)
		{
			hCellModify--;
			cout << "Which card(from the top of the stack) would you like to move: ";
			cin >> cardToMove;
			if (cardToMove > 0 and cardToMove <= 8)
			{
				cardToMove--;
			
				//if the card is an ace
				if (m_freecellTable.GetPlaycell()[cardToMove].Peek().getRank() == One)
				{
					Card temp = m_freecellTable.GetPlaycell()[cardToMove].Pop();
					m_freecellTable.GetHomecell()[hCellModify].Push(temp);
				}
				//else card must not be in stack
				else
				{
					//check if suits match and that the list is not empty
					if (!m_freecellTable.GetHomecell()[hCellModify].isEmpty() && m_freecellTable.GetPlaycell()[cardToMove].Peek().getSuit() == m_freecellTable.GetHomecell()[hCellModify].Peek().getSuit())
					{
						if (m_freecellTable.GetPlaycell()[cardToMove].Peek().getRank() == m_freecellTable.GetHomecell()[hCellModify].Peek().getRank() + 1)
						{
							Card temp = m_freecellTable.GetPlaycell()[cardToMove].Pop();
							m_freecellTable.GetHomecell()[hCellModify].Push(temp);

						}
					}
				}
			}
		}
	}
	//if player chose to edit the freecell
	else if (input == 'f' || input == 'F')
	{
		int freecellNum = 0;
		int playcellCard = 0;
		cout << "Which freecell would you like to modify (1-4) : ";
		cin >> freecellNum;
		if (freecellNum > 0 && freecellNum <= 4)
		{
			freecellNum--;
			//if the freecell is empty
			if (m_freecellTable.GetFreecell()[freecellNum].getSuit() == X)
			{
				cout << "Which card(from the top of the stack) would you like to move : ";
				cin >> playcellCard;
				playcellCard--;
				//if the playcell is not empty
				if (!m_freecellTable.GetPlaycell()[playcellCard].isEmpty())
				{
					Card temp = m_freecellTable.GetPlaycell()[playcellCard].Pop();
					m_freecellTable.GetFreecell()[freecellNum] = temp;
				}
			}
			//else the freecell has a card in the spot
			else
			{
				char input2 = '\0';
				cout << "Would you like to move it to a homecell or playcell";
				cin >> input2;
				if (input2 == 'p' || input2 == 'P')
				{
					cout << "Where would you like to move the card(which freecell stack?): ";
					cin >> playcellCard;
					playcellCard--;
					//if the playcell is open
					if (m_freecellTable.GetPlaycell()[playcellCard].isEmpty())
					{
						Card temp = m_freecellTable.GetFreecell()[playcellCard];
						Card defaultCard(0, 0);
						m_freecellTable.GetFreecell()[freecellNum] = defaultCard;
						m_freecellTable.GetPlaycell()[playcellCard].Push(temp);
					}
					//else Playcell has at least one card in it
					else
					{
						RANKS temprank = m_freecellTable.GetPlaycell()[playcellCard].Peek().getRank();
						SUITS tempsuit = m_freecellTable.GetPlaycell()[playcellCard].Peek().getSuit();
						SUITS currentsuit = m_freecellTable.GetFreecell()[freecellNum].getSuit();
						RANKS currentrank = m_freecellTable.GetFreecell()[freecellNum].getRank();
						//Check if rank is opposite color
						//if rank is black/white
						if (tempsuit == C || tempsuit == S)
						{
							//if the rank freecell card is red
							if (currentsuit == H || currentsuit == D)
							{
								//if the suit of the playcell card = freecell card + 1
								if (temprank == currentrank + 1)
								{
									//add card to playcell
									Card temp = m_freecellTable.GetFreecell()[freecellNum];
									Card defaultCard(0, 0);
									m_freecellTable.GetFreecell()[freecellNum] = defaultCard;
									m_freecellTable.GetPlaycell()[playcellCard].Push(temp);
								}
							}
						}
						//else the rank is red
						else if (tempsuit == H || tempsuit == D)
						{
							if (currentsuit == C || currentsuit == S)
							{
								//if the suit of the playcell card = freecell card + 1
								if (temprank == currentrank + 1)
								{
									//add card to playcell
									Card temp = m_freecellTable.GetFreecell()[playcellCard];
									Card defaultCard(0, 0);
									m_freecellTable.GetFreecell()[freecellNum] = defaultCard;
									m_freecellTable.GetPlaycell()[playcellCard].Push(temp);
								}
							}

						}
						//Check if suit is equal to 1 - suit in playcell
					}
				}
				//input must be a homecell
				else
				{
					int homecellToMoveToo = 0;
					cout << "Which homecell(1-4) : ";
					cin >> homecellToMoveToo;
					//if user is in bounds
					if (homecellToMoveToo > 0 && homecellToMoveToo <= 4)
					{
						homecellToMoveToo--;
						//check if card in freecell is an ace
						if (m_freecellTable.GetFreecell()[freecellNum].getRank() == One)
						{
							//if yes then move card to homcell and replace freecell card with default/0
							Card freecelltemp(0,0);
							Card temp = m_freecellTable.GetFreecell()[freecellNum];
							m_freecellTable.GetHomecell()[homecellToMoveToo].Push(temp);
							m_freecellTable.GetFreecell()[freecellNum] = freecelltemp;
						}
						//else card must not be in stack
						else
						{
							//check if suits match and that the list is not empty
							if (!m_freecellTable.GetHomecell()[homecellToMoveToo].isEmpty() && m_freecellTable.GetFreecell()[freecellNum].getSuit() == m_freecellTable.GetHomecell()[homecellToMoveToo].Peek().getSuit())
							{
								if (m_freecellTable.GetFreecell()[freecellNum].getRank() == m_freecellTable.GetHomecell()[homecellToMoveToo].Peek().getRank() + 1)
								{
									Card freecelltemp;
									Card temp = m_freecellTable.GetFreecell()[freecellNum];
									m_freecellTable.GetHomecell()[homecellToMoveToo].Push(temp);
									m_freecellTable.GetFreecell()[freecellNum] = freecelltemp;
								}
							}
						}

					}
				}
			}
		}
	}
	//if user chose playcell
	else if (input == 'p' || input == 'P')
	{
		int playcellToModify = 0;
		int cardsToMove = 0;
		int cardsMovable = m_freecellTable.NumOfCardsMovable();
		cout << "Which stack would you like to modify (1-8) : ";
		cin >> playcellToModify;
		playcellToModify--;
		cout << "How many card would you like too move? : ";
		cin >> cardsToMove;
		//if user wants to move only 1 card
		if (cardsToMove == 1)
		{
			char inputMoveTo = '\0';
			cout << "Where would you like to move the card to? Homecell(h), freecell(f), or playcell(p) : ";
			cin >> inputMoveTo;
			if (inputMoveTo == 'h' || inputMoveTo == 'H')
			{
				int moveToHome = 0;
				cout << "Which homecell? : ";
				cin >> moveToHome;
				//if in bounds
				if (moveToHome > 0 && moveToHome <= 4)
				{
					moveToHome--;
					//check if card is an ace
					if (m_freecellTable.GetPlaycell()[playcellToModify].Peek().getRank() == One)
					{
						Card temp = m_freecellTable.GetPlaycell()[playcellToModify].Pop();
						m_freecellTable.GetHomecell()[moveToHome].Push(temp);
					}
					else
					{
						//Check if suits match and that cell is not empty and that rank-1 == rank in home cell
						if (!m_freecellTable.GetHomecell()[moveToHome].isEmpty() &&
							m_freecellTable.GetPlaycell()[playcellToModify].Peek().getRank() - 1 == m_freecellTable.GetHomecell()[moveToHome].Peek().getRank()
							&& m_freecellTable.GetPlaycell()[playcellToModify].Peek().getSuit() == m_freecellTable.GetHomecell()[moveToHome].Peek().getSuit())
						{
							Card temp = m_freecellTable.GetPlaycell()[playcellToModify].Pop();
							m_freecellTable.GetHomecell()[moveToHome].Push(temp);

						}
					}
				}
			}
			//else if f
			else if (inputMoveTo == 'f' || inputMoveTo == 'F')
				//	see if freecell is open
			{
				int moveToFreecell = 0;
				cout << "Which freecell would you like to move the card too (1-4) :";
				cin >> moveToFreecell;
				//if user is in bounds
				if (moveToFreecell > 0 && moveToFreecell <= 4)
				{
					//Decrement user value 
					moveToFreecell--;
					//if freecell is empty/ has a default suit of X
					if (m_freecellTable.GetFreecell()[moveToFreecell].getSuit() == X)
					{
						//Create Temp card
						Card tempPlayCard = m_freecellTable.GetPlaycell()[playcellToModify].Pop();
						//Insert temp card into user chosen spot in the freecell area
						m_freecellTable.GetFreecell()[moveToFreecell] = tempPlayCard;
					}
				}
			}
			//if user chose play cell area
			else if (inputMoveTo == 'P' || inputMoveTo == 'p')
			{
				int playcellToModify2 = 0;
				cout << "Which play cell would you like to move the card too (1-8) : ";
				cin >> playcellToModify2;
				//if user is in bounds
				if (playcellToModify2 > 0 && playcellToModify2 <= 8)
				{
					playcellToModify2--;
					//if playcell is empty
					if (m_freecellTable.GetPlaycell()[playcellToModify2].isEmpty())
					{
						
						/*if (m_freecellTable.NumOfCardsMovable >= 0)
						{*/
							Card tempPlayCard = m_freecellTable.GetPlaycell()[playcellToModify].Pop();
							m_freecellTable.GetPlaycell()[playcellToModify2].Push(tempPlayCard);
						//}
					}
					else
					{
						//check to see if suit is opposite and 
						//check to see if rank of playcellToModify
						//is == playcellToModify2 rank + 1 
						RANKS playrank_temp1 = m_freecellTable.GetPlaycell()[playcellToModify].Peek().getRank();
						RANKS playrank_temp2 = m_freecellTable.GetPlaycell()[playcellToModify2].Peek().getRank();
						SUITS playsuit_temp1 = m_freecellTable.GetPlaycell()[playcellToModify].Peek().getSuit();
						SUITS playsuit_temp2 = m_freecellTable.GetPlaycell()[playcellToModify2].Peek().getSuit();
						//if suits are opposite
						if ((playsuit_temp1 == S || playsuit_temp1 == C) && (playsuit_temp2 != S || playsuit_temp2 != C))
						{
							//if ranks2 +1 = ranks
							if (playrank_temp1 == playrank_temp2 - 1)
							{
								//pop card to move
								Card tempplaycard = m_freecellTable.GetPlaycell()[playcellToModify].Pop();
								//add card to playcell
								m_freecellTable.GetPlaycell()[playcellToModify2].Push(tempplaycard);
							}
						}
						else
						{
							//if ranks2 +1 = ranks
							if (playrank_temp1 == playrank_temp2 - 1)
							{
								//pop card to move
								Card tempplaycard = m_freecellTable.GetPlaycell()[playcellToModify].Pop();
								//add card to playcell
								m_freecellTable.GetPlaycell()[playcellToModify2].Push(tempplaycard);
							}
						}
					}
				}
			}
		}
		else if (cardsToMove > 1)
		{
			int playcellToMoveToo = 0;
			//Ask where they want to move the stack in the play area
			cout << "Where would you like to move your stack of cards? (1-8) : ";
			cin >> playcellToMoveToo;
			//check if user is in bounds
			if (playcellToMoveToo > 0 && playcellToMoveToo <= 8)
			{
				playcellToMoveToo--;
				//Check if you can move that many cards
				if (cardsToMove + 1 <= m_freecellTable.NumOfCardsMovable())
				{
					//can only move cards to playcells
					//create temp stack
					StackLL<Card> tempPlayCell = m_freecellTable.GetPlaycell()[playcellToModify];
					StackLL<Card> tempPlayCell2;
					bool movePossible = true;
					//for each card, check the suit if they are opposite and if they are
					//Check if stack follows pattern
					for (int i = 0; i < cardsToMove - 1; ++i)
					{
						RANKS temprank1 = tempPlayCell.Peek().getRank();
						SUITS tempsuit1 = tempPlayCell.Pop().getSuit();
						RANKS temprank2 = tempPlayCell.Peek().getRank();
						SUITS tempsuit2 = tempPlayCell.Peek().getSuit();
						//if the suits are opposite
						if ((tempsuit1 == C || tempsuit1 == S) && (tempsuit2 == C || tempsuit2 == S))
						{
							if (temprank1 != temprank2 - 1)
							{
								movePossible = false;
							}
						}
					}
					//if stack follows pattern pop all items off playcell stack
					//	and push them onto stack to move to
					if (movePossible)
					{
						for (int i = 0; i < cardsToMove; ++i)
						{
							tempPlayCell2.Push(m_freecellTable.GetPlaycell()[playcellToModify].Pop());
						}
						for (int i = 0; i < cardsToMove; ++i)
						{
							m_freecellTable.GetPlaycell()[playcellToMoveToo].Push(tempPlayCell2.Pop());
						}
					}
				}
			}
		}
	}
}
/*
	Purpose: The purpose of this method is to check if the player has won the game

	Precondition
		None

	Postcondition:
		return a bool
*/
bool Freecell::isGameWon()
{
	bool gameWon = true;
	//for each playcell
	for (int playcellCount = 0; playcellCount < 8; ++playcellCount)
	{
		//if each playcell is empty, half of game is won
		if (!m_freecellTable.GetPlaycell()[playcellCount].isEmpty())
			gameWon = false;
	}
	//for each freecell
	for (int freecellCount = 0; freecellCount < 4; ++freecellCount)
	{
		//if each freecell is empty also, game is won
		if (m_freecellTable.GetFreecell()[freecellCount].getSuit() != X)
			gameWon = false;
	}

	return gameWon;
}
