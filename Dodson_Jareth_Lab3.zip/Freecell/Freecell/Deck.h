/*
	Class: Deck

	Purpose: Create a deck of 52 card objects

	Manager Functions:
		Deck()
			Creates a default deck with all 52 cards in order
		Deck(const Deck & copy)
			Shallow copies data from copy
		operator=(const Deck & rhs)
			Deep copies data from rhs
		~Deck()
			
	Methods:
		DealTop()
			Deals the top card of the deck and returns it
		ShowTop()
			Returns the top of the deck to see
		DisplayDeck();
			Displays all 52 cards of the deck
		Shuffle();
			Shuffles the deck of cards 21 times for an efficient shuffle
	
*/
#ifndef DECK_H
#define DECK_H
#include <stdlib.h>
#include <time.h>
#include "Card.h"
#include "Array.h"
class Deck
{
	public:
		Deck();
		Deck(const Deck & copy);
		Deck & operator=(const Deck & rhs);
		~Deck();

		Card DealTop();
		Card ShowTop();
		void DisplayDeck();
		void Shuffle();

	private:
		Array<Card> m_deck;
		int m_current;
};
#endif // !DECK_H