#include "Table.h"

char suitDisplay[5] = { 'X','C', 'D', 'S', 'H' };
char rankDisplay[14] = {'X', '1','2','3','4','5','6','7','8','9','T','J','Q','K' };
/*
	Purpose: Creates a table with 52 different cards

	Precondtion:
		Table must be instantiated
	Postcondtion:
		Table is created 
		m_homecell is modified
		m_playcell is modified
		m_freecell is modified
*/
Table::Table() : m_freecell(4), m_homecell(4), m_playcell(8), m_gamedeck()
{
	for (int homecellCount = 0; homecellCount < 4; ++homecellCount)
	{
		m_homecell[homecellCount].setSize(13);
	}
	m_gamedeck.Shuffle();
	//First 48 cards
	for (int i = 0; i < 8; ++i)
	{
		for (int playcellNum = 0; playcellNum < 6; ++playcellNum)
		{
			m_playcell[i].Push(m_gamedeck.DealTop());
			}
	}
	//Last 4 cards
	for (int x = 0; x < 4; ++x)
	{
		m_playcell[x].Push(m_gamedeck.DealTop());
	}
}
/*
	Purpose: Shallow copies the data members of copy

	Precondtion:
		Must have a Table previously created
	Postcondtion:
		m_homecell is modified
		m_playcell is modified
		m_freecell is modified
		m_gamedeck is modified
*/
Table::Table(const Table & copy) : 
	m_freecell(copy.m_freecell), m_homecell(copy.m_homecell),
	m_playcell(copy.m_playcell), m_gamedeck(copy.m_gamedeck)
{
}
/*
	Purpose: Override = operator

	Precondtion:
		lhs and rhs must be created already
	Postcondtion:
		lhs is equal to rhs
*/
Table & Table::operator=(const Table & rhs)
{
	if (this != &rhs)
	{
		m_freecell = rhs.m_freecell;
		m_homecell = rhs.m_homecell;
		m_playcell = rhs.m_playcell;
		m_gamedeck = rhs.m_gamedeck;
	}
	return *this;
}

/*
	Purpose: Table DTOR

	Precondtion:
		None
	Postcondtion:
		None
*/
Table::~Table()
{
}

/*
	Purpose: Display the table

	Precondtion:
		Table must be already created
	Postcondtion:
		Displays the freecells, homecells and playcells
*/
void Table::DisplayTable()
{
	system("CLS");
	int i = 0;
	COORD coord;
	coord.X = i + 1;
	coord.Y = m_playcell[i].Size() + 1;
	Array<StackLL<Card>> tempPlayCell = m_playcell;
	cout << " ";
	for (int i = 0; i < 4; ++i)
		cout << setw(5) << i + 1;
	cout << " ";
	for (int i = 0; i < 4; ++i)
		cout << setw(5) << i + 1;
	cout << endl;
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	cout << "   ";
	//Display Freecells
	for (int freeCount = 0; freeCount < 4; ++freeCount)
	{
		if (rankDisplay[m_freecell[freeCount].getSuit()] == 'X')
			cout << "| - |";
		else
		{
			cout << "|";
			if (m_freecell[freeCount].getSuit() == C || m_freecell[freeCount].getSuit() == S)
				SetConsoleTextAttribute(hConsole, 14);
			else
				SetConsoleTextAttribute(hConsole, 12);
			cout << rankDisplay[m_freecell[freeCount].getRank()] << "-" << suitDisplay[m_freecell[freeCount].getSuit()];
			SetConsoleTextAttribute(hConsole, 15);
			cout << "|";
		}
	}
	cout << "*";
	
	//Display Homecells
	for (int homeCount = 0; homeCount < 4; ++homeCount)
	{
		try {
			cout << "|";
			if (m_homecell[homeCount].Peek().getSuit() == C || m_homecell[homeCount].Peek().getSuit() == S)
				SetConsoleTextAttribute(hConsole, 14);
			else
				SetConsoleTextAttribute(hConsole, 12);
			cout << rankDisplay[m_homecell[homeCount].Peek().getRank()] << "-" << suitDisplay[m_homecell[homeCount].Peek().getSuit()];
			SetConsoleTextAttribute(hConsole, 15);
			cout << "|";// << ;// endl;
		}
		catch(Exception & exception)
		{
			cout << " - |";
		}
	}
	coord.X = 0;
	coord.Y = 3;
	SetConsoleCursorPosition(hConsole, coord);
	/*cout << " ";*/
	for (int i = 0; i < 8; ++i)
	{
		cout << setw(5) << i + 1;
	}
	coord.X = 0;
	coord.Y = 4;
	SetConsoleCursorPosition(hConsole, coord);

	//Display Playcells
	cout << '\n';
	for (i = 0; i < 8; ++i)
	{
		coord.Y = m_playcell[i].Size() + 3;

		SetConsoleCursorPosition(hConsole, coord);
		for (int x = 0; x < m_playcell[i].Size(); ++x)
		{
	
			SetConsoleCursorPosition(hConsole, coord);
			if (i == 0)
			{
				cout << x + 1<< " ";
			}
			cout << "|";
			if (tempPlayCell[i].Peek().getSuit() == C || tempPlayCell[i].Peek().getSuit() == S)
				SetConsoleTextAttribute(hConsole, 14);
			else
				SetConsoleTextAttribute(hConsole, 12);
			
			cout << rankDisplay[tempPlayCell[i].Peek().getRank()] << "-" << suitDisplay[tempPlayCell[i].Peek().getSuit()];
			SetConsoleTextAttribute(hConsole, 15);
			cout << "| " << endl;
			coord.Y--;
			tempPlayCell[i].Pop();
		}
		if (i == 0)
			coord.X += 7;
		else
			coord.X += 5;
		cout << endl;
	}
	
	coord.X = 0;
	coord.Y = 15;
	SetConsoleCursorPosition(hConsole, coord);

}
/*
	Purpose: Get the number of cards that are possible to move

	Precondtion:
		None
	Postcondtion:
		returns the number of cards possible to move
*/
int Table::NumOfCardsMovable()
{
	int CardsMovable = 0;
	//Get Number of empty freecells
	for (int i = 0; i < 4; ++i)
	{
		if (m_freecell[i].getRank() == X)
			CardsMovable++;
	}
	//Get number of empty play cells
	for (int i = 0; i < 8; ++i)
	{
		if (m_playcell[i].isEmpty())
			CardsMovable *= 2;
	}
	return CardsMovable + 1;
}
/*
	Purpose: Get the playcell area

	Precondtion:
		Table must be instantiated
	Postcondtion:
		Returns m_playcell
*/
Array<StackLL<Card>> & Table::GetPlaycell()
{
	return m_playcell;
}
/*
	Purpose: Get homecell area

	Precondtion:
		Table must be instantiated
	Postcondtion:
		Returns m_homecell
*/
Array<StackA<Card>> & Table::GetHomecell()
{
	return m_homecell;
}
/*
	Purpose: Get freecell area

	Precondtion:
		Table must be instantiated
	Postcondtion:
		returns m_freecell
*/
Array<Card> & Table::GetFreecell()
{
	return m_freecell;
}
