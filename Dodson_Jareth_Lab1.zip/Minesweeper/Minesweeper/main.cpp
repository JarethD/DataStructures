/*
	Lab 1 - Minesweeper
	Jareth Dodson
	1-19-19

	Overview:
		This program will play the game minesweeper.
		The player chooses 1 of the 3 difficulties.
		The player uses numerical values to the spot and 'u' or '?' to indicate the choice
*/

#include "Minesweeper.h"

int main()
{
	srand(time(NULL));
	Minesweeper Game;
	Game.StartGame(); 
	return 0;
}