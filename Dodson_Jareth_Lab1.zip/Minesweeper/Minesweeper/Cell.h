#pragma once
#ifndef CELL_H
#define CELL_H

#include <iostream>

using std::cout;
using std::endl;

/*
	Class Cell

	Purpose: This class creates a minesweeper cell with
	multiples possibles states

	Manager Functions:
		Cell()
		Cell(const Cell & copy)
		Cell & operator=(const Cell & rhs)
		~Cell()
	
	Methods:
		DisplayCell()

	Setter and Getters:
		void SetBomb(bool bomb)
		void SetCover(bool cover)
		void SetNumOfBombs(int numbOfBombs)
		void SetMark(bool mark)
		bool GetBomb()
		bool GetCover()
		int GetNumOfBombs()
		bool GetMark()		
*/


class Cell
{
	public:
		Cell();
		Cell(const Cell & copy);
		Cell & operator=(const Cell & rhs);
		~Cell();
		void DisplayCell();
		//SETTERS/GETTERS
		void SetBomb(bool bomb);
		void SetCover(bool cover);
		void SetNumOfBombs(int numbOfBombs);
		void SetMark(bool mark);
		bool GetBomb();
		bool GetCover();
		int GetNumOfBombs();
		bool GetMark();

	private:
		bool m_bomb;
		bool m_covered;
		int m_numOfBombs; //Number of bombs around the cell
		bool m_marked;
};
#endif CELL_H