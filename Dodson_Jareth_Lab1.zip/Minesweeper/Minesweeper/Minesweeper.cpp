#include "Minesweeper.h"

/*
	Purpose: Create a minesweeper object with default values

	Precondtion:
		None

	Postcondtion:
		Minesweeper game created
*/
Minesweeper::Minesweeper() : m_input('\0')
{
}

/*
	Purpose: Copy a minesweeper object

	Precondtion:
		Pre-existing copy object

	Postcondtion:
		Minesweeper copied to a new object
*/
Minesweeper::Minesweeper(const Minesweeper & copy) : m_input('\0')
{
}

/*
	Purpose: Override the operator =
		
	Precondtion:
		A left hand side and a right hand side

	Postcondtion:
		right hand side copied over to the left hand side
*/
Minesweeper & Minesweeper::operator=(const Minesweeper & rhs)
{
	if (this != &rhs)
	{
		m_input = rhs.m_input;
		m_board = rhs.m_board;
	}
	return *this;
}

/*
	Purpose: Destructor

	Precondtion: 
		None

	Postcondtion:
		reset value to default
*/
Minesweeper::~Minesweeper()
{
	m_input = '\0';
}

/*
	Purpose: Start minesweeper

	Precondtion:
		Existing Minesweeper object

	Postcondtion:
		Starts game
*/
void Minesweeper::StartGame()
{
	cout << "Beginner, Intermediate or Expert?";
	cin >> m_input;
	Board newBoard(m_input);
	m_board = newBoard;
	int x_coord = 0;
	int y_coord = 0;
	char mark = '\0';
	bool cellMark = false;
	int GameOver = 0;
	while (GameOver == 0)
	{
		system("CLS");
		m_board.DisplayBoard();
		cout << "\nEnter X Coord";
		cin >> x_coord;
		cout << "\nEnter Y Coord";
		cin >> y_coord;
		cout << "Mark as bomb(?) or Uncover(U)?";
		cin >> mark;
		if (mark == '?')
			cellMark = true;
		else
			cellMark = false;
		if(x_coord > 0 && x_coord <= m_board.GetBoardColumns())
			if(y_coord > 0 && y_coord <= m_board.GetBoardRows())
				m_board.PlayMove(x_coord-1, y_coord-1, cellMark);
		GameOver = m_board.GetGameOver();
		if(GameOver != 1)
			GameOver = m_board.PlayerWon();

	}
	if (GameOver == 1)
		cout << "\n\nGame Over - You hit a bomb!" << endl;
	else if (GameOver == 2)
		cout << "\n\n\t\tCongrats!! You won!" << endl;
}