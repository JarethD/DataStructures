#include "Board.h"

/*
	Purpose: Create a default board

	Precondtion:
		Creation of board object

	Postcondtion:
		board object created
*/
Board::Board() : m_rows(0), m_columns(0), m_numOfMines(0), m_input('\0')
{

}

/*
	Purpose: Create a board object with values depending on the input

	Precondtion:
		Creation of board object

	Postcondtion:
		Board object created
*/
Board::Board(char input) : m_input(input), m_rows(0), m_columns(0), m_gameOver(false)
{
	if (input == 'B' || input == 'b')
	{
		m_rows = 10;
		m_columns = 10;
		m_numOfMines = 10;
	}
	else if (input == 'I' || input == 'i')
	{
		m_rows = 16;
		m_columns = 16;
		m_numOfMines = 40;
	}
	else if(input == 'E' || input == 'e')
	{
		m_rows = 16;
		m_columns = 32;
		m_numOfMines = 100;
	}
	Array2D<Cell> board(m_rows, m_columns);
	m_board = board;
	int minesPlaced = 0;
	int bombs = 0;

	while (minesPlaced < m_numOfMines)
	{
		bombs = rand() % 10;
		
		for(int i = 0; i < m_board.GetRow() && minesPlaced < m_numOfMines; ++i)
			for (int j = 0; j < m_board.GetColumns() && minesPlaced < m_numOfMines; ++j)
			{
				bombs = rand() % 100;
				if (bombs < 8 && !m_board[i][j].GetBomb())
				{
					m_board[i][j].SetBomb(true);
					minesPlaced++;
				}
			}

	}
	for (int i = 0; i < m_board.GetRow(); ++i)
		for (int j = 0; j < m_board.GetColumns(); ++j)
			if(!m_board[i][j].GetBomb())
				m_board[i][j].SetNumOfBombs(CountBombs(i,j));
}

/*
	Purpose: Copy a board object to another

	Precondition
		copy - a board object

	Postcondition
		data members are set to copy's data members
*/
Board::Board(const Board & copy) :
	m_board(copy.m_board), m_columns(copy.m_columns), m_rows(copy.m_rows),
	m_gameOver(copy.m_gameOver), m_input(copy.m_input), m_numOfMines(copy.m_numOfMines)
{
}

/*
	Purpose: Override the operator =

	Precondtion:
		rhs - board object

	Postconditon:
		data members are set to rhs's data member if they don't equal each other
*/
Board & Board::operator=(const Board & rhs)
{
	if (this != &rhs)
	{
		m_board = rhs.m_board;
		m_columns = rhs.m_columns;
		m_rows = rhs.m_rows;
		m_gameOver = rhs.m_gameOver;
		m_input = rhs.m_input;
		m_numOfMines = rhs.m_numOfMines;
	}
	return *this;
}

/*
	Purpose: Destuctor of board object

	Precondtion:
		board object

	Postcondtion:
		reset values to default
*/
Board::~Board()
{
	m_rows = 0;
	m_columns = 0;
	m_numOfMines = 0;
	m_gameOver = 0;
	m_input = ('\0');
}

/*
	Purpose: Display the board
	
	Precondtion:
		Board object

	Postcondtion:
		Display board
*/
void Board::DisplayBoard()
{
	cout << "+";
	for (int i = 0; i < m_rows * 2; ++i)
		cout << "-";
	cout << "+" << endl;
	for (int x = m_rows- 1; x >= 0; --x)
	{
		cout << "|";
		for (int i = 0; i < m_columns; ++i)
		{
			m_board[x][i].DisplayCell();
			cout << "|";
		}
		cout << "\n";
	}
	cout << "+";
	for (int i = 0; i < m_rows * 2; ++i)
		cout << "-";
	cout << "+";
}

/*
	Purpose: Play the move the character has given

	Precondtion:
		xcoord - positive value
		ycoord - positive value
		mark - either true or false

	Postcondtion:
		Play the move the play has given at xcoord, ycoord
*/
void Board::PlayMove(int xcoord, int ycoord, bool mark)
{
	if (mark)
	{
		//Do checks everywhere to see if the spot is marked or not
		// if the spot is marked you can't uncover the spot(unless you mark it again?)
		m_board[ycoord][xcoord].SetMark(true);
	}
	else if (m_board[ycoord][xcoord].GetCover())
	{
		if (m_board[ycoord][xcoord].GetBomb())
		{
			cout << "end Game" << endl;
			m_gameOver = 1; //Game over by bomb
		}
		else if(m_board[ycoord][xcoord].GetNumOfBombs() == 0 && !m_board[ycoord][xcoord].GetBomb())
		{
			//Flood uncover
			FloodUncover(ycoord, xcoord);
		}
	}
	m_board[ycoord][xcoord].SetCover(false);

}

/*
	Purpose: Count the bombs around a cell

	Precondtion:
		xcoord - positive value
		ycoord - positive value

	Postcondtion:
		returns the amount of bombs around xcoord, ycoord
*/
int Board::CountBombs(int xcoord, int ycoord)
{
	int count = 0;
	//Check all 8 surrounding cells
	if (xcoord >= 0 && xcoord < m_rows
		&& ycoord >= 0 && ycoord < m_columns)
	{
		//Check Top
		if (xcoord - 1 >= 0 && xcoord-1 < m_rows)
			if(m_board[xcoord - 1][ycoord].GetBomb())
			{
				++count;
			}
		//Check Bottom
		if (xcoord + 1 >= 0 && xcoord + 1 < m_rows)
			if (m_board[xcoord + 1][ycoord].GetBomb())
			{
				++count;
			}
		//Check Right
		if (ycoord - 1 >= 0 && ycoord - 1 < m_columns)
			if (m_board[xcoord][ycoord-1].GetBomb())
			{
				++count;
			}
		//Check Left
		if (ycoord + 1 >= 0 && ycoord + 1 < m_columns)
			if (m_board[xcoord][ycoord+1].GetBomb())
			{
				++count;
			}
		//Check Bottom Right
		if (xcoord + 1 >= 0 && xcoord + 1 < m_rows
			&& ycoord - 1 >= 0&& ycoord - 1 < m_columns)
		{
			if (m_board[xcoord + 1][ycoord - 1].GetBomb())
			{
				++count;
			}
		}
//		Check Bottom Left
		if (xcoord + 1 >= 0 && xcoord + 1 < m_rows
			&& ycoord + 1 >= 0 && ycoord + 1 < m_columns)
		{
			if (m_board[xcoord + 1][ycoord + 1].GetBomb())
			{
				++count;
			}
		}
		//Check Top right
		if (xcoord - 1 >= 0 && xcoord - 1 < m_rows
			&& ycoord - 1 >= 0 && ycoord - 1 < m_columns)
		{
			if (m_board[xcoord - 1][ycoord - 1].GetBomb())
			{
				++count;
			}
		}
		//Check Top Left
		if (xcoord - 1 >= 0 && xcoord - 1 < m_rows
			&& ycoord + 1 >= 0 && ycoord + 1 < m_columns)
		{
			if (m_board[xcoord - 1][ycoord + 1].GetBomb())
			{
				++count;
			}
		}

	}

	return count;
}

/*
	Purpose: Uncover all surrounding empty cell and there corresponding valued cells

	Precondtion:
		xcoord - positive value
		ycoord - positive value

	Postcondtion:
		uncovers all surrounding empty cells
*/
void Board::FloodUncover(int xcoord, int ycoord)
{
	if (xcoord >= 0 && xcoord < m_rows && ycoord >= 0 
		&& ycoord < m_columns && m_board[xcoord][ycoord].GetNumOfBombs() == 0 
		&& !m_board[xcoord][ycoord].GetMark()
		&& m_board[xcoord][ycoord].GetCover())
	{
		UncoverNumbers(xcoord, ycoord);
		m_board[xcoord][ycoord].SetCover(false);
		if (xcoord -1 >= 0 && xcoord - 1 < m_rows)
			FloodUncover(xcoord - 1, ycoord);
		if (xcoord +1 >= 0 && xcoord + 1 < m_rows)
			FloodUncover(xcoord + 1, ycoord);
		if (ycoord -1 >= 0 && xcoord - 1 < m_columns)
			FloodUncover(xcoord, ycoord - 1);
		if (ycoord +1 >= 0 && xcoord + 1 < m_columns)
			FloodUncover(xcoord, ycoord + 1);
	}
}

/*
	Purpose: Uncover all numbered cells around xcoord, ycoord

	Precondtion:
		xcoord - positive value
		ycoord - positive value

	Postcondtion:
		Uncovers all numbered cells around the cells
*/
void Board::UncoverNumbers(int xcoord, int ycoord)
{
		if (xcoord >= 0 && xcoord < m_rows
		&& ycoord >= 0 && ycoord < m_columns)
	{
		//Uncover Top
		if (xcoord - 1 >= 0 && xcoord - 1 < m_rows)
			if(m_board[xcoord - 1][ycoord].GetNumOfBombs() > 0 
				&& !m_board[xcoord - 1][ycoord].GetBomb())
				m_board[xcoord - 1][ycoord].SetCover(false);
		//Uncover Bottom
		if (xcoord + 1 >= 0 && xcoord + 1 < m_rows)
			if (m_board[xcoord + 1][ycoord].GetNumOfBombs() > 0 && !m_board[xcoord + 1][ycoord].GetBomb())
				m_board[xcoord + 1][ycoord].SetCover(false);
		//Uncover Right
		if (ycoord - 1 >= 0 && ycoord - 1 < m_columns)
			if (m_board[xcoord][ycoord - 1].GetNumOfBombs() > 0 && !m_board[xcoord][ycoord - 1].GetBomb())
				m_board[xcoord][ycoord - 1].SetCover(false);
		//Uncover Left
		if (ycoord + 1 >= 0 && ycoord + 1 < m_columns)
			if (m_board[xcoord][ycoord + 1].GetNumOfBombs() > 0 && !m_board[xcoord][ycoord + 1].GetBomb())
				m_board[xcoord][ycoord + 1].SetCover(false);
		//uncover Bottom Right
		if (xcoord + 1 >= 0 && xcoord + 1 < m_rows
			&& ycoord - 1 >= 0&& ycoord - 1 < m_columns)
		{
			if (m_board[xcoord + 1][ycoord - 1].GetNumOfBombs() > 0 && !m_board[xcoord + 1][ycoord - 1].GetBomb())
				m_board[xcoord + 1][ycoord - 1].SetCover(false);
		}
		//Check Bottom Left
		if (xcoord + 1 >= 0 && xcoord + 1 < m_rows
			&& ycoord + 1 >= 0 && ycoord + 1 < m_columns)
		{
			if (m_board[xcoord + 1][ycoord + 1].GetNumOfBombs() > 0 && !m_board[xcoord + 1][ycoord + 1].GetBomb())
				m_board[xcoord + 1][ycoord + 1].SetCover(false);
		}
		//Check Top right
		if (xcoord - 1 >= 0 && xcoord - 1 < m_rows
			&& ycoord - 1 >= 0 && ycoord - 1 < m_columns)
		{
			if (m_board[xcoord - 1][ycoord - 1].GetNumOfBombs() > 0 && !m_board[xcoord - 1][ycoord - 1].GetBomb())
				m_board[xcoord - 1][ycoord - 1].SetCover(false);
		}
		//Check Top Left
		if (xcoord - 1 >= 0 && xcoord - 1 < m_rows
			&& ycoord + 1 >= 0 && ycoord + 1 < m_columns)
		{
			if (m_board[xcoord - 1][ycoord + 1].GetNumOfBombs() > 0 && !m_board[xcoord - 1][ycoord + 1].GetBomb())
				m_board[xcoord - 1][ycoord + 1].SetCover(false);
		}

	}
}

/*
	Purpose: Checks if the player won the game

	Precondtion:
		Board object

	Postcondtion:
		returns 2 if the player won
		returns 0 if the player is still playing
*/
int Board::PlayerWon()
{
	int isWon = 2;

	for (int rows = 0; rows < m_rows; ++rows)
	{
		for (int col = 0; col < m_columns; ++col)
		{
			//if all tiles that aren't bombs are open and all bomb tiles are covered and have a ?
			//if the tils is a bomb
			if (m_board[rows][col].GetBomb())
				//if the tile is still covered
				if (m_board[rows][col].GetCover())
					//and if the tile does not have a mark
					if (!m_board[rows][col].GetMark())
						//game not won
						isWon = 0;
			//if the tile is covered
			if(!m_board[rows][col].GetBomb())
				if (m_board[rows][col].GetCover())
				//game not won
				isWon = 0;
		}
	}


	return isWon;
}

/*
	Purpose: Get the number of rows

	Precondtion:
		Existing board object

	Postcondtion:
		returns the amount of rows on the board
*/
int Board::GetBoardRows()
{
	return m_rows;
}

/*
	Purpose: Get the number of columns

	Precondtion:
		Existing board object

	Postcondtion:
		returns the amount of columns on the board
*/
int Board::GetBoardColumns()
{
	return m_columns;
}

/*
	Purpose: Get the value of the game over variable

	Precondtion:
		Existing board object

	Postcondtion:
		returns the value of game over, either 0, 1 or 2
*/
int Board::GetGameOver()
{
	return m_gameOver;
}
