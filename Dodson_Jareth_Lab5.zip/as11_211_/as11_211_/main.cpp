/*
	Author: Jareth Dodson
	File name: main.cpp

	Lab 4 - Late - Dijkstras

	Purpose: The purpose of this lab was to use our graph class 
		to implement dijkstras shortest path algorithm
	

	Problems:
		Not enough checks in Graph.h
		Can't get dijkstras to work
		
	Wish I could've gotten this working
*/

#include <string>
#include "Graph.h"
#include <vector>

using std::vector;
using std::string;
template <typename V, typename E>
void visit(Vertex<V, E> *vertex);


//Does not work
template <typename V, typename E>
void dijkstra(Graph<V, E> & graph, V from, V to, int size)
{
	int * predecessors = new int[size];
	int * dist = new int[size];
	
	for (int i = 0; i < size; ++i)
	{
		dist[i] = -1;
		predecessors[i] = -1;
	}

	//distance from self
	dist[0] = 0;


	
	typename list<Vertex<V, E>>::iterator iter = graph.getVertices().begin();
	while ((*iter).getData() != from)
		++iter;
	
	//for the size of the graph
	for (int i = 1; i < size-1; ++i, ++iter)
	{
		//Not sure why this won't work
		//iterator to the list<Arc<V, E>> in vertex.h
		typename list<Arc<V, E>>::iterator arciter = (*iter).getEdges().begin();
		//loop for entire list
		for (; arciter != (*iter).getEdges().end(); ++arciter)
			//if the weight of arciter is less than the current or is empty
			if ((*arciter).getWeight() < dist[i]  || dist[i] == -1)
				//add the lowest weight to the distance array
				dist[i] = (*arciter).getWeight();
		if ((*iter).getData() == to)
			break;
	}

	delete[] dist;
	delete[] predecessors;
}


template <typename V, typename E>
int main()
{

	Graph<string, string> g1;
	g1.InsertVertex("A");
	g1.InsertVertex("B");
	g1.InsertArc("A", "B", "AB", 3);
	g1.InsertVertex("C");
	g1.InsertArc("B", "C", "BC", 1);
	g1.InsertVertex("D");
	g1.InsertArc("D", "B", "DB", 9);
	g1.InsertVertex("E");
	g1.InsertArc("D", "E", "DE", 4);
	g1.InsertArc("C", "E", "CE", 3);
	g1.InsertVertex("F");
	g1.InsertArc("E", "F", "EF", 8);
	//dijkstra(g1, "A", "E", 6);


	return 0;
}

template<typename V, typename E>
void visit(Vertex<V, E>* vertex)
{
	cout << vertex->getData() << " ";
}
