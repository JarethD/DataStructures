/*
	Class: List

	Purpose: Creates an empty Doubly linked list with multiple functionalities

	Manager functions:
		List()
			Default List with data members set to nullptr
		List(const List & copy)
			Shallow copies the data from copy
		operator=(const List & rhs)
			Deep copies the data from rhs
		~List()
			List DTOR
				Reset values to default value

	Methods:
		IsEmpty()
			Returns a bool whether the list is empty or not
		First()
			Returns the first value in the list for modification
		Last()
			Returns the Last value in the list for modification
		Prepend(Node<T> data)
			Adds the data to the beginning of the list
		Append(Node<T> data)
			Adds the data to the end of the list
		Purge()
			Deletes all items in the list and frees up memory
		Exctract(T data)
			deletes data in the list
		InsertAfter(T new_item, T existing_item)
			Inserts new_item after existing_item
		InsertBefore(T new_item, T existing_item)
			Inserts new_item before existing_item
*/
#pragma once
#ifndef LIST_H
#define LIST_H
#include "Exception.h"
#include "Node.h"
#include "BackwardIterator.h"
#include "ForwardIterator.h"
#include <iostream>

using std::cout;
using std::endl;

template <typename T>
class List
{
public:
	List();
	List(const List & copy);
	List<T> & operator=(const List & rhs);
	~List();

	bool IsEmpty();
	const T & First();
	const T & Last();
	void Prepend(Node<T> data);
	void Append(Node<T> data);
	void Purge();//
	void Extract(T data);
	void InsertAfter(T new_item, T existing_item);
	void InsertBefore(T new_item, T existing_item);

	ForwardIterator<T> f_begin();
	ForwardIterator<T> f_end();
	BackwardIterator<T> b_begin();
	BackwardIterator<T> b_end();

	//TESTING(should be private)
	Node<T> * GetHead() const;
	Node<T> * GetTail() const;
	void PrintForwards();
	void PrintBackwards();

private:
	Node<T> * m_head;
	Node<T> * m_tail;

};

template<typename T>
inline List<T>::List() :
	m_head(nullptr), m_tail(nullptr)
{
}

template<typename T>
inline List<T>::List(const List & copy) :
	m_head(nullptr), m_tail(nullptr)
{
	Node<T> * travel = copy.m_head;
	while (travel != nullptr)
	{
		Append(travel->m_data);
		travel = travel->m_next;
	}
}

template<typename T>
inline List<T>& List<T>::operator=(const List & rhs)
{
	if (this != &rhs)
	{
		Purge();
		Node<T> * travel = rhs.m_head;
		while (travel != nullptr)
		{
			Append(travel->m_data);
			travel = travel->m_next;
		}
	}
	return *this;
}

template<typename T>
inline List<T>::~List()
{
	Purge();
	m_head = nullptr;
	m_tail = nullptr;
}

template<typename T>
inline bool List<T>::IsEmpty()
{
	bool empty = false;
	if (m_head == nullptr)
		empty = true;
	return empty;
}

template<typename T>
inline const T& List<T>::First()
{
	return m_head->m_data;
}

template<typename T>
inline const T& List<T>::Last()
{
	return m_tail->m_data;
}

template<typename T>
inline void List<T>::Prepend(Node<T> data)
{
	Node<T> * nn = new Node<T>(data);
	if (m_head == nullptr)
	{
		m_tail = nn;
		m_head = nn;
	}
	else
	{
		nn->m_next = m_head;
		m_head->m_prev = nn;
		m_head = nn;
	}
}

template<typename T>
inline void List<T>::Append(Node<T> data)
{
	Node<T> * nn = new Node<T>(data);
	if (m_tail == nullptr)
	{
		m_tail = nn;
		m_head = nn;
	}
	else
	{
		m_tail->m_next = nn;
		nn->m_prev = m_tail;
		m_tail = nn;
	}
}

template<typename T>
inline void List<T>::Purge()
{
	Node<T> * travel = nullptr;

	while (m_head != nullptr)
	{
		travel = m_head;
		m_head = m_head->m_next;
		delete travel;
		travel = nullptr;
	}
	m_head = nullptr;
	m_tail = nullptr;
}

template<typename T>
inline void List<T>::Extract(T data)
{
	Node<T> * travel = m_head;
	Node<T> * trail = nullptr;
	if (m_head == nullptr)
	{
		throw Exception("List is empty");
	}
	//if travel is first w/ existing data
	else if (travel->m_data == data && travel->m_next != nullptr)
	{
		m_head = travel->m_next;
		m_head->m_prev = nullptr;
		delete travel;
		travel = nullptr;
	}
	//if node is only data in list
	else if (m_head->m_next == nullptr)
	{
		delete m_head;
		m_head = nullptr;
		m_tail = nullptr;
	}
	else
	{
		while (travel != nullptr && travel->m_data != data)
		{
			trail = travel;
			travel = travel->m_next;
		}
		if (travel == nullptr)
			throw Exception("Error");
		//if node is tail
		else if (travel == m_tail)
		{
			trail->m_next = nullptr;
			travel->m_prev = nullptr;
			delete m_tail;
			m_tail = m_head;
		}
		//if node is in middle
		else
		{
			trail->m_next = travel->m_next;
			travel->m_next->m_prev = travel->m_prev;

			delete travel;
		}
	}
}

template<typename T>
inline void List<T>::InsertAfter(T new_item, T existing_item)
{
	Node<T> * travel = m_head;
	Node<T> * trail = nullptr;
	if (m_head == nullptr)
	{
		throw Exception("Error");
	}
	else if (m_head->m_data == existing_item && m_head == m_tail)
	{
		Node<T> * nn = new Node<T>(new_item);
		m_head->m_next = nn;
		m_tail = nn;
		nn->m_prev = m_head;
	}
	else if (m_head == m_tail)
	{
		if (m_head->m_data != existing_item)
			throw Exception("Error");
	}
	else
	{
		while (travel->m_data != existing_item && travel != nullptr)
		{
			trail = travel;
			travel = travel->m_next;
		}
		if (travel == nullptr)
			throw Exception("Error");
		Node<T> * nn = new Node<T>(new_item);
		nn->m_next = travel->m_next;
		travel->m_next->m_prev = nn;
		travel->m_next = nn;
		nn->m_prev = travel;
	}
}

template<typename T>
inline void List<T>::InsertBefore(T new_item, T existing_item)
{
	Node<T> * travel = m_head;
	Node<T> * trail = nullptr;
	if (m_head == nullptr)
	{
		throw Exception("Error");
	}
	else if (m_head->m_data == existing_item)
	{
		Node<T> * nn = new Node<T>(new_item);
		nn->m_next = m_head;
		m_head->m_prev = nn;
		m_head = nn;
	}
	else if (m_head == m_tail)
	{
		if (m_head->m_data != existing_item)
			throw Exception("Error");
	}
	else
	{
		while (travel->m_data != existing_item && travel != nullptr)
		{
			trail = travel;
			travel = travel->m_next;
		}
		if (travel == nullptr)
			throw Exception("Error");
		Node<T> * nn = new Node<T>(new_item);

		nn->m_next = travel;
		trail->m_next = nn;
		nn->m_prev = trail;
		travel->m_prev = nn;
	}
}

template<typename T>
inline ForwardIterator<T> List<T>::f_begin()
{
	return ForwardIterator<T>(m_head);
}

template<typename T>
inline ForwardIterator<T> List<T>::f_end()
{
	return ForwardIterator<T>(m_tail);
}

template<typename T>
inline BackwardIterator<T> List<T>::b_begin()
{
	return BackwardIterator<T>(m_tail);
}

template<typename T>
inline BackwardIterator<T> List<T>::b_end()
{
	return BackwardIterator<T>(m_head);
}


template<typename T>
inline Node<T>* List<T>::GetHead() const
{
	return m_head;
}

template<typename T>
inline Node<T>* List<T>::GetTail() const
{
	return m_tail;
}

template<typename T>
inline void List<T>::PrintForwards()
{
	Node<T> * travel = new Node<T>;
	travel = m_head;
	while (travel != nullptr)
	{
		cout << travel->m_data << endl;
		travel = travel->m_next;
	}
}

template<typename T>
inline void List<T>::PrintBackwards()
{
	Node<T> * travel = m_tail;
	while (travel != nullptr)
	{
		cout << travel->m_data << endl;
		travel = travel->m_prev;
	}
}
#endif // !LIST_H