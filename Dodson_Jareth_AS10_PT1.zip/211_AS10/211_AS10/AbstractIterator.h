#pragma once
#ifndef ABSTRACTITERATOR_H
#define ABSTRACTITERATOR_H

template <typename T>
class AbstractIterator
{
public:
	//virtual AbstractIterator();
	virtual ~AbstractIterator() = default;
	virtual void MoveNext() = 0;
	virtual void Reset() = 0;
	virtual bool IsDone() const = 0;
	virtual T & GetCurrent() = 0;
	virtual T GetCurrent() const = 0;
};


#endif // !ABSTRACTITERATOR_H
//
//template<typename T>
//inline AbstractIterator<T>::AbstractIterator()
//{
//}
//
//template<typename T>
//inline AbstractIterator<T>::~AbstractIterator()
//{
//}
