#pragma once
#ifndef BACKWARDITERATOR_H
#define BACKWARDITERATOR_H

#include "ListIterator.h"

template <typename T>
class List;

template <typename T>
class BackwardIterator : public ListIterator<T>
{
	public:
		friend class List<T>;
		BackwardIterator();
		~BackwardIterator();
		explicit BackwardIterator(Node<T> * data);
		BackwardIterator(const BackwardIterator<T> & copy);
		virtual BackwardIterator<T> & operator=(const BackwardIterator<T> & rhs);
		bool operator==(const BackwardIterator & rhs);
		bool operator!=(const BackwardIterator & rhs);

		void MoveNext() override;
		void Reset();
		BackwardIterator<T> & operator++();
		const BackwardIterator<T> operator++(int);
};

#endif // !BackwardIterator_H

template<typename T>
inline BackwardIterator<T>::BackwardIterator()
{
}

template<typename T>
inline BackwardIterator<T>::~BackwardIterator()
{
}

template<typename T>
inline BackwardIterator<T>::BackwardIterator(Node<T>* data)
{
	ListIterator<T>::m_itNode = data;
}

template<typename T>
inline BackwardIterator<T>::BackwardIterator(const BackwardIterator<T>& copy) :ListIterator<T>(copy)
{
}

template<typename T>
inline BackwardIterator<T>& BackwardIterator<T>::operator=(const BackwardIterator<T>& rhs)
{
	if (this != &rhs)
	{
		ListIterator<T>::m_itNode = rhs.BackwardIterator<T>::m_itNode;
	}
	return *this;
}

template<typename T>
inline bool BackwardIterator<T>::operator==(const BackwardIterator & rhs)
{
	bool pass = false;
	if (rhs.ListIterator<T>::m_itNode == ListIterator<T>::m_itNode)
		pass = true;
	return pass;
}

template<typename T>
inline bool BackwardIterator<T>::operator!=(const BackwardIterator & rhs)
{
	return !(rhs.ListIterator<T>::m_itNode == ListIterator<T>::m_itNode);
}

template<typename T>
inline void BackwardIterator<T>::MoveNext()
{
	ListIterator<T>::m_itNode = ListIterator<T>::m_itNode->GetPrevious();
}

template<typename T>
inline void BackwardIterator<T>::Reset()
{
	while (ListIterator<T>::m_itNode->GetNext() != nullptr)
		ListIterator<T>::m_itNode = ListIterator<T>::m_itNode->GetNext();
}

template<typename T>
inline BackwardIterator<T>& BackwardIterator<T>::operator++()
{
	MoveNext();
	return *this;
}

template<typename T>
inline const BackwardIterator<T> BackwardIterator<T>::operator++(int)
{
	const auto temp = *this;
	MoveNext();
	return temp;
}
