/*
	Author : Jareth Dodson
	Date Created: 2-28-19

	Purpose:
		The purpose of this program is to test and use an implementation
			of a forward and backward iterator for a linked list
*/


#include "List.h"

int main()
{
	List<int> list;
	for (int i = 1; i < 10; ++i)
		list.Append(i);
	ForwardIterator<int> it_ = list.f_begin();
	ForwardIterator<int> it_2 = it_;
	//it_2 = it_;
	cout << *it_ << endl;
	++it_;
	cout << *it_ << endl;
	it_++;
	cout << *it_ << endl;
	it_.Reset();
	cout << *it_ << endl;
	if (it_ != it_2)
		cout << "not equal" << endl;
	else
		cout << "equal" << endl;
	
	BackwardIterator<int> _it = list.b_begin();
	BackwardIterator<int> _it2;
	_it2 = _it;
	cout << *_it2 << endl;
	++_it;
	_it++;
	cout << _it.GetCurrent() << endl;

	if (_it == _it2)
		cout << "equal" << endl;
	else
		cout << "not equal" << endl;

	return 0;
}