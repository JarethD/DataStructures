#ifndef LISTITERATOR_H
#define LISTITERATOR_H

#include "AbstractIterator.h"
#include "Node.h"
template <typename T>
class List;

template <typename T>
class ListIterator : public AbstractIterator<T>
{
public:
	friend class List<T>;
	ListIterator();
	ListIterator(const ListIterator<T> & copy);
	ListIterator<T> & operator=(const ListIterator<T> & rhs);
	virtual ~ListIterator();


	bool IsDone() const noexcept override;
	T & GetCurrent();
	T GetCurrent() const;
	T& operator*();
	T operator*() const;


protected:
	Node<T> * m_itNode;
	bool m_done;

};

template<typename T>
inline ListIterator<T>::ListIterator() : m_itNode(nullptr), m_done(true)
{
}

template<typename T>
inline ListIterator<T>::ListIterator(const ListIterator<T>& copy) : m_itNode(copy.m_itNode), m_done(copy.m_done)
{
}

template<typename T>
inline ListIterator<T> & ListIterator<T>::operator=(const ListIterator<T>& rhs)
{
	if (this != &rhs)
	{
		m_itNode = rhs.m_itNode;
		m_done = rhs.m_done;
	}
	return *this;
}

template<typename T>
inline T & ListIterator<T>::operator*()
{
	return m_itNode->GetData();
}

template <typename T>
inline T ListIterator<T>::operator*() const
{
	return m_itNode->GetData();
}

template<typename T>
inline ListIterator<T>::~ListIterator()
{
	//default
	m_itNode = nullptr;
	m_done = false;
}

template<typename T>
inline bool ListIterator<T>::IsDone() const noexcept
{
	bool done = false;
	if (m_itNode->GetNext() == nullptr)
		done = true;
	return done;
}

template<typename T>
inline T & ListIterator<T>::GetCurrent()
{
	return m_itNode->GetData();
}

template<typename T>
inline T ListIterator<T>::GetCurrent() const
{
	return m_itNode->GetData();
}


#endif // !LISTITERATOR_H
