#pragma once
#ifndef FORWARDITERATOR_H
#define FORWARDITERATOR_H

#include "ListIterator.h"

template <typename T>
class List;

template <typename T>
class ForwardIterator : public ListIterator<T>
{
	public:
		friend class List<T>;
		ForwardIterator();
		~ForwardIterator();
		explicit ForwardIterator(Node<T> * data);
		ForwardIterator(const ForwardIterator<T> & copy);
		virtual ForwardIterator<T> & operator=(const ForwardIterator<T> & rhs);
		bool operator==(const ForwardIterator<T> & rhs);
		bool operator!=(const ForwardIterator<T> & rhs);

		void MoveNext() override;
		void Reset();
		ForwardIterator<T> & operator++(); //post increment
		const ForwardIterator<T> operator++(int); //pre increment
};


template<typename T>
inline ForwardIterator<T>::ForwardIterator()
{
}

template<typename T>
inline ForwardIterator<T>::~ForwardIterator()
{
}

template<typename T>
inline ForwardIterator<T>::ForwardIterator(Node<T> * data)
{
	ListIterator<T>::m_itNode = data;
}

template<typename T>
inline ForwardIterator<T>::ForwardIterator(const ForwardIterator<T>& copy) : ListIterator<T>(copy)
{
}

template<typename T>
inline ForwardIterator<T>& ForwardIterator<T>::operator=(const ForwardIterator<T>& rhs)
{
	if (this != &rhs)
	{
		ListIterator<T>::m_itNode = rhs.ForwardIterator<T>::m_itNode;
	}
	return *this;
}

template<typename T>
inline bool ForwardIterator<T>::operator==(const ForwardIterator<T>& rhs)
{
	bool pass = false;
	if (rhs.ListIterator<T>::m_itNode == ListIterator<T>::m_itNode)
		pass = true;
	return pass;
}

template<typename T>
inline bool ForwardIterator<T>::operator!=(const ForwardIterator<T>& rhs)
{
	return !(rhs.ListIterator<T>::m_itNode == ListIterator<T>::m_itNode);
}

template<typename T>
inline void ForwardIterator<T>::MoveNext()
{
	if (ListIterator<T>::m_itNode == nullptr)
		throw Exception("end of list");
	ListIterator<T>::m_itNode = ListIterator<T>::m_itNode->GetNext();
}

template<typename T>
inline void ForwardIterator<T>::Reset()
{
	while (ListIterator<T>::m_itNode->GetPrevious() != nullptr)
		ListIterator<T>::m_itNode = ListIterator<T>::m_itNode->GetPrevious();
}

template<typename T>
inline ForwardIterator<T> & ForwardIterator<T>::operator++()
{
	MoveNext();
	return *this;
}

template<typename T>
inline const ForwardIterator<T> ForwardIterator<T>::operator++(int)
{
	const auto temp = *this;
	MoveNext();
	return temp;
}
#endif // !FORWARDITERATOR_H
