#ifndef QUEUE_H
#define QUEUE_h
/*
	Author: Jareth Dodson
	File Name: Queue.h
	Date created: 2-5-19

	Purpose: This class will represent a circular queue, with a fixed size,
		that uses my array class as the data structure

	Throw exceptions for underflow and underflow conditions
*/
#include "Array.h"

template <typename T>
class Queue
{
	public:
		Queue();
		Queue(int size);
		Queue(const Queue & copy);
		Queue<T> & operator=(const Queue& rhs);
		~Queue();

		void Enqueue(T data);
		T Dequeue();
		T & Front();
		int Size();
		bool isEmpty();
		bool isFull();

	private:
		int m_size;
		int m_head;
		int m_tail;
		Array<T> m_queue;

};

#endif // !QUEUE_H
template <typename T>
inline Queue<T>::Queue() : m_size(1), m_head(-1), m_tail(-1), m_size(1)
{

}

//1-ARG CTOR
template<typename T>
inline Queue<T>::Queue(int size) :m_size(size), m_head(-1), m_tail(-1), m_queue(size)
{
}

//COPY CTOR
template<typename T>
inline Queue<T>::Queue(const Queue & copy) : m_queue(copy.m_queue), m_head(copy.m_head), m_size(copy.m_size), m_tail(copy.m_tail)
{
}

//OP=
template<typename T>
inline Queue<T>& Queue<T>::operator=(const Queue & rhs)
{
	if (this != &rhs)
	{
		m_head = rhs.m_head;
		m_tail = rhs.m_tail;
		m_size = rhs.m_size;
		m_queue = rhs.m_queue;
	}
	return *this;
}

//DTOR
template<typename T>
inline Queue<T>::~Queue()
{
	m_size = 0;
	m_head = 0;
	m_tail = 0;
}


//Add item to end of list
template<typename T>
inline void Queue<T>::Enqueue(T data)
{
	//if list is full throw Exception
	if (isFull())
		throw Exception("Overflow error");
	if (m_tail == m_size-1 && m_tail != 0)
	{
		m_tail = 0;
		m_queue[m_tail] = data;
	}
	//if list is empty
	else if (m_head == -1)
	{
		m_head++;
		m_tail++;
		m_queue[m_head] = data;
	}
	//else list has at least one item so add to end of queue
	else
	{
		m_tail++;
		m_queue[m_tail] = data;
	}
}

//Return item in the beginning of queue
template<typename T>
inline T Queue<T>::Dequeue()
{
	
	//if the list is empty throw underflow exception
	if (isEmpty())
	{
		throw Exception("Underflow Error");
		return -1;
	}
	T tempData = m_queue[m_head];
	
	//if head is at the end of array set head equal to 0/ beginning of array
	if (m_head >= m_size - 1)
		m_head = 0;
	//if m_head and m_tail equal each other list has one item
	else if (m_head == m_tail)
	{
		m_head = -1;
		m_tail = -1;
	}
	else
		m_head++;
	return tempData;
}

template<typename T>
inline T & Queue<T>::Front()
{
	if (isEmpty())
		throw Exception("List is empty, cannot get top");
	return m_queue[m_head];
}

template<typename T>
inline int Queue<T>::Size()
{
	return (m_size - m_head + m_tail) % m_size;
}

template<typename T>
inline bool Queue<T>::isEmpty()
{
	bool empty = false;
	if (Size() == 0)
		empty = true;
	return empty;
}

template<typename T>
inline bool Queue<T>::isFull()
{
	bool full = false;
	if (Size() == m_size-1 || m_head == m_tail+1)
		full = true;
	return full;
}
