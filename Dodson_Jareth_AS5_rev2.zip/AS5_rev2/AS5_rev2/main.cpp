/*
	Jareth Dodson
	Assignmnet 5 revision
	2-15-19
*/

#include "Stack.h"
#include <iostream>

using namespace std;


int main()
{
	//1 arg ctor
	Stack<int> s1(10);

	//push check
	for (int i = 0; i < 10; i++)
		s1.Push(i);

	//Pop check
	for (int i = 0; i < 10; i++)
		cout << s1.Pop() << " ";

	//copy ctor
	Stack<int> s2 = s1;
	
	for (int i = 0; i < 10; i++)
		s2.Push(i);
	cout << '\n';
	
	//op=
	Stack<int> s3;
	s3 = s2;
	for (int i = 0; i < 10; i++)
		cout << s3.Pop() << " ";

	//Peek
	Stack<int> s4(10);
	s4.Push(5);
	s4.Push(10);
	cout << s4.Peek();
	s4.Pop();
	s4.Pop();
	
	//is empty test
	if (s4.isEmpty())
		cout << "true";
	else
		cout << "false";

	for (int i = 0; i < 10; ++i)
		s4.Push(i);
	
	cout << endl;

	//is full test
	if (s4.isFull())
		cout << "true";
	else
		cout << "false";

}