#ifndef ARRAY2D_H
#define ARRAY2D_H

#include "Array.h"
#include "Row.h"

template <typename T>
class Array2D
{
	public:
		Array2D();
		Array2D(const int row, const int col = 0);
		Array2D(const Array2D<T> & copy);
		~Array2D();

		Array2D<T> & operator=(const Array2D<T> & rhs);
		Row<T> operator[](const int index);

		//SETTERS/GETTERS
		int GetColumns() const;
		int GetRow() const;
		void SetColumns(int col);
		void SetRows(int row);
		T & Select(int row, int column);			   

	private:
		Array<T> m_array;
		int m_row;
		int m_col;
};


template<typename T>
inline Array2D<T>::Array2D() : m_row(0), m_col(0), m_array()
{
}

template<typename T>
inline Array2D<T>::Array2D(const int row, const int col) :
	m_row(row), m_col(col), m_array(row * col)
{
	if (row < 0 || col < 0)
		throw Exception("Less than 0");
}

template<typename T>
inline Array2D<T>::Array2D(const Array2D<T>& copy) :
	m_row(copy.m_row), m_col(copy.m_col), m_array(copy.m_array)
{
}

template<typename T>
inline Array2D<T>::~Array2D()
{
	m_row = 0;
	m_col = 0;
}

template<typename T>
inline Array2D<T>& Array2D<T>::operator=(const Array2D<T> & rhs)
{
	if (this != &rhs)
	{
		m_array = rhs.m_array;
		m_row = rhs.m_row;
		m_col = rhs.m_col;
	}
	return *this;
}

template<typename T>
inline Row<T> Array2D<T>::operator[](const int index)
{
	return Row<T>((*this), index);
}

template<typename T>
inline int Array2D<T>::GetColumns() const
{
	return m_col;
}

template<typename T>
inline int Array2D<T>::GetRow() const
{
	return m_row;
}

template<typename T>
inline void Array2D<T>::SetColumns(int col)
{
	if (col < 0)
		throw Exception("Value less than 0");
	int smaller = (m_col > col) ? col : m_col;
	Array<T> temp(col * m_row);
	for (int x = 0; x < m_row; ++x)
	{
		for (int i = 0; i < smaller; ++i)
		{
			temp[x * col + i ] = m_array[x * m_col + i];
		}
	}
	m_col = col;
	m_array = temp;
}

template<typename T>
inline void Array2D<T>::SetRows(int row)
{
	if (row < 0)
		throw Exception("Value less than 0");
	m_array.SetLength(row * m_col);
	m_row = row;
}

template<typename T>
inline T & Array2D<T>::Select(int row, int column)
{
	if (row < 0 || column < 0)
		throw Exception("Value less than 0");
	else if (row > m_row || column > m_col)
		throw Exception("Value less than 0");
	return m_array[row * m_col + column];
}






#endif // !ARRAY2D_H