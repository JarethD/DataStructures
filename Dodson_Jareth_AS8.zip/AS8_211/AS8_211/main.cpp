#include "Queue.h"
#include "string.h"

using std::string;

bool ctor_test();
bool complex_ctor_test();
bool copy_ctor();
bool op_equal();
bool enqueue_test();
bool dequeue_test();
bool front_test();
bool size_test();
bool is_empty_test();
bool underflow_test();


int main()
{
	bool passed = false;
	passed = ctor_test();
	if (passed)
		cout << "Ctor Test: passed" << endl;
	else
		cout << "Ctor Test: failed" << endl;

	//Complex Ctor Test
	passed = complex_ctor_test();
	if (passed)
		cout << "Complex Ctor Test: passed" << endl;
	else
		cout << "Complex Ctor Test: failed" << endl;
	
	//Operator = test
	passed = op_equal();
	if (passed)
		cout << "Operator = Test: passed" << endl;
	else
		cout << "Operator = Test: failed" << endl;
	
	//Enqueue Test
	passed = enqueue_test();
	if (passed)
		cout << "Enqueue Test: passed" << endl;
	else
		cout << "Enqueue Test: failed" << endl;

	//Dequeue Test
	passed = dequeue_test();
	if (passed)
		cout << "Dequeue Test: passed" << endl;
	else
		cout << "Dequeue Test: failed" << endl;
	
	//Front Test
	passed = front_test();
	if (passed)
		cout << "Front Test: passed" << endl;
	else
		cout << "Front Test: failed" << endl;

	//Size Test
	passed = size_test();
	if (passed)
		cout << "Size Test: passed" << endl;
	else
		cout << "Size Test: failed" << endl;

	//isEmpty Test
	is_empty_test();
	if (passed)
		cout << "Is Empty Test: passed" << endl;
	else
		cout << "Is Empty Test: failed" << endl;

	//Underflow Test
	passed = underflow_test();
	if (passed)
		cout << "Underflow Test: passed" << endl;
	else
		cout << "Underflow Test: failed" << endl;

	return 0;
}

bool ctor_test()
{
	bool pass = true;
	{
		Queue<int> queue_test;
		if (queue_test.Size() != 0)
			pass = false;
	}
	return pass;
}

bool complex_ctor_test()
{
	bool pass = true;
	{
		Queue<string> queue_test;
		if (queue_test.Size() != 0)
			pass = false;
	}
	return pass;
}

bool copy_ctor()
{
	bool pass = true;
	{
		Queue<int> test_queue;
		test_queue.Enqueue(4);
		Queue<int> test_queue2 = test_queue;
		if (test_queue.Size() != test_queue2.Size())
			pass = false;
		if (test_queue2.Front() != test_queue.Front())
			pass = false;
	}
	return false;
}

bool op_equal()
{
	bool pass = true;
	{
		Queue<int> test_queue;
		test_queue.Enqueue(4);
		Queue<int> test_queue2;
		test_queue2 = test_queue;
		if (test_queue.Size() != test_queue2.Size())
			pass = false;
		if (test_queue.Front() != test_queue2.Front())
			pass = false;
	}
	return pass;
}

bool enqueue_test()
{
	bool pass = true;
	{
		Queue<int> test_queue;
		for (int i = 0; i < 10; ++i)
			test_queue.Enqueue(i);
		if (test_queue.Front() != 0)
			pass = false;
	}
	
	return pass;
}

bool dequeue_test()
{
	bool pass = true;
	{
		Queue<int> test_queue;
		for (int i = 0; i < 10; ++i)
			test_queue.Enqueue(i);
		for (int i = 0; i < 9; ++i)
			test_queue.Dequeue();
		if (test_queue.Front() != 9)
			pass = false;
	}
	return pass;
}

bool front_test()
{
	bool pass = true;
	Queue<int> test_queue;
	test_queue.Enqueue(65);
	test_queue.Front() = 100;
	if (test_queue.Front() != 100)
		pass = false;
	return pass;
}

bool size_test()
{
	bool pass = true;
	{
		Queue<int> test_queue;
		for (int i = 0; i < 24; ++i)
			test_queue.Enqueue(i);
		if (test_queue.Size() != 24)
			pass = false;
	}

	return pass;
}

bool is_empty_test()
{
	bool pass = true;
	{
		Queue<int> test_queue;
		if (test_queue.Size() != 0)
			pass = false;
		test_queue.Enqueue(5);
		if (test_queue.Size() != 1)
			pass = false;
	}
	return pass;
}

bool underflow_test()
{
	bool pass = false;
	{
		Queue<int> test_queue;
		try
		{
			test_queue.Dequeue();
		}
		catch (Exception & exception)
		{
			pass = true;
		}
	}
	return pass;
}
