#include "List.h"

/*
	Author: Jareth Dodson
	File name: Queue.h
	Date Created: 2-6-18

	Purpose: This class will create a queue using 
		a linked list as the data structure
*/

template <typename T>
class Queue
{
	public:
		Queue();
		Queue(const Queue<T> & copy);
		Queue<T> & operator=(const Queue<T> & rhs);
		~Queue();

		void Enqueue(T data);
		T Dequeue();
		T & Front();
		int Size();
		bool isEmpty();

	private:
		List<T> m_queue;
		int m_size;
};

template<typename T>
inline Queue<T>::Queue() : m_queue(), m_size(0)
{
}

template<typename T>
inline Queue<T>::Queue(const Queue<T>& copy) : m_queue(copy.m_queue), m_size(copy.m_size)
{
}

template<typename T>
inline Queue<T>& Queue<T>::operator=(const Queue<T>& rhs)
{
	if (this != &rhs)
	{
		m_queue = rhs.m_queue;
		m_size = rhs.m_size;
	}
	return *this;
}

template<typename T>
inline Queue<T>::~Queue()
{
	m_size = 0;
}

template<typename T>
inline void  Queue<T>::Enqueue(T data)
{
	m_queue.Append(data);
	m_size++;
}

template<typename T>
inline T Queue<T>::Dequeue()
{
	if (m_queue.GetHead() == nullptr)
		throw Exception("Underflow error");
	T temp = m_queue.First();
	m_queue.Extract(m_queue.First());
	m_size--;
	return temp;
}

template<typename T>
inline T & Queue<T>::Front()
{
	return m_queue.First();
}

template<typename T>
inline int Queue<T>::Size()
{
	return m_size;
}

template<typename T>
inline bool Queue<T>::isEmpty()
{
	return m_queue.IsEmpty();
}
