#pragma once
#ifndef HASHNODE_H
#define HASHNODE_H

template <typename K, typename V>
class HashNode
{
	public:
		HashNode();
		HashNode(K key, V value);
		~HashNode();
		HashNode(const HashNode<K, V> & copy);
		HashNode(HashNode<K, V> && copy);

		HashNode<K, V> & operator=(const HashNode<K, V> & rhs);

		K getKey() const;
		V getValue() const;
		void setKey(K key);
	private:
		K m_key;
		V m_value;
};

#endif // !HASHNODE_H

template<typename K, typename V>
inline HashNode<K, V>::HashNode()
{
}

template<typename K, typename V>
inline HashNode<K, V>::HashNode(K key, V value) : m_key(key), m_value(value)
{
}

template<typename K, typename V>
inline HashNode<K, V>::~HashNode()
{
}

template<typename K, typename V>
inline HashNode<K, V>::HashNode(const HashNode<K, V>& copy) : m_key(copy.m_key), m_value(copy.m_value)
{
}

template<typename K, typename V>
inline HashNode<K, V>::HashNode(HashNode<K, V>&& copy) : m_key(copy.m_key), m_value(copy.m_value)
{
}

template<typename K, typename V>
inline HashNode<K, V>& HashNode<K, V>::operator=(const HashNode<K, V>& rhs)
{
	if (this != &rhs)
	{
		m_key = rhs.m_key;
		m_value = rhs.m_value;
	}
	return *this;
}
//
//template<typename K, typename V>
//inline bool HashNode<K, V>::operator==(const HashNode<K, V>& rhs)
//{
//	bool pass = false;
//
//	if (m_key == rhs.m_key)
//		if (m_value == rhs.m_value)
//			pass = true;
//
//	return pass;
//}

template<typename K, typename V>
inline K HashNode<K, V>::getKey() const
{
	return m_key;
}

template<typename K, typename V>
inline V HashNode<K, V>::getValue() const
{
	return m_value;
}

template<typename K, typename V>
inline void HashNode<K, V>::setKey(K key)
{
	m_key = key;
}
