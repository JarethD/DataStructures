/*
	Author: Jareth Dodson

	Hash Table Lab 6

	Problems:
		Rehash doesn't work
		Not sure what to put in visit function

*/


#include <iostream>
#include <string>
#include "HashTable.h"

using std::string;
using std::cout;
using std::endl;

struct Book
{
	string m_title;
	string m_author;
	int m_pages;
};


//Size of Hash Table
int TABLESIZE = 10;

//Hash Function
int hash(string key)
{
	int hashval = 0;
	for (int x = 0; x < key.length(); ++x)
	{
		hashval += key[x];
	}
	return hashval % TABLESIZE;
}


template<typename V>
void visit(V value)
{
	//???
	//cout << value;
}

int main()
{

	Book b1 = { "How to tetris 99", "Northernlion", 50 };
	Book b2 = { "How to solve a rubiks cube", "Me", 100 };
	Book b3 = { "A murder mystery", "You", 564 };
	HashTable<string, Book> table(TABLESIZE);
	table.setHash(hash);
	
	table.Insert("076358523", b1);
	table.Insert("795321822", b2);
	table.Insert("745132196", b3);

	cout << table["076358523"].m_title;
	
	table.Delete("076358523");
	table.Traverse(visit);
	return 0;
}