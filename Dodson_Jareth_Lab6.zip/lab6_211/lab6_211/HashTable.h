#pragma once
#ifndef HASHTABLE_H
#define HASHTABLE_H
#include <vector>
#include <list>
#include <iostream>
#include <iterator>
#include "HashNode.h"

using std::list;
using std::iterator;
using std::vector;
using std::cout;

template <typename K, typename V>
class HashTable
{
	public:
		HashTable();
		HashTable(int size);
		~HashTable();
		HashTable(const HashTable<K, V> & copy);
		HashTable(HashTable<K, V> && copy);

		HashTable<K, V> & operator=(const HashTable<K, V> & rhs);


		void Insert(K key, V value);
		void setHash(int(*hash)(K key));
		V operator[](K key);
		void Delete(K key);
		void Traverse(void(*visit)(V value));
		void Rehash(int size);
		

	private:
		vector<list<HashNode<K, V>>> m_bucket;
		//HashNode<K, V> m_temp;
		int m_size;
		int(*hashFunc)(K key);
		//int hash(K key);
		

};

#endif // !HASHTABLE_H

template<typename K, typename V>
inline HashTable<K, V>::HashTable()
{
}

template<typename K, typename V>
 inline HashTable<K, V>::HashTable(int size) :m_size(size)
{
	 /////////Rehash(size);
	 m_bucket.resize(size);
}

 template<typename K, typename V>
 inline HashTable<K, V>::~HashTable()
 {
	 m_size = 0;
 }

 template<typename K, typename V>
 inline HashTable<K, V>::HashTable(const HashTable<K, V>& copy) : m_size(copy.m_size), m_bucket(copy.m_bucket)
 {
 }

 template<typename K, typename V>
 inline HashTable<K, V>& HashTable<K, V>::operator=(const HashTable<K, V>& rhs)
 {
	 if (this != &rhs)
	 {
		 m_size = rhs.m_size;
		 hashFunc = rhs.hashFunc;
		 Rehash(rhs.m_size);
	 }
 }

 template<typename K, typename V>
 inline void HashTable<K, V>::Insert(K key, V value)
 {
	 int hashVal = hashFunc(key);

	 HashNode<K, V> temp(key, value);
	 m_bucket[hashVal].push_back(temp);
	 
 }

 template<typename K, typename V>
 inline void HashTable<K, V>::setHash(int(*hash)(K key))
 {
	 hashFunc = hash;
 }

 template<typename K, typename V>
 inline V HashTable<K, V>::operator[](K key)
 {
	 V val;
	 K element;
	 
	 typename vector<list<HashNode<K, V>>>::iterator iter = m_bucket.begin();
	 for (; iter != m_bucket.end(); ++iter)
	 {
		 for (typename list<HashNode<K, V>>::iterator listIter = (*iter).begin();
			 listIter != (*iter).end(); ++listIter)
		 {
			 element = (*listIter).getKey();
			 if (element == key)
				 return (*listIter).getValue();
		 }
	 }


	 return val;
 }

 template<typename K, typename V>
 inline void HashTable<K, V>::Delete(K key)
 {
	 for (typename list<HashNode<K, V>>::iterator iter = m_bucket[hashFunc(key)].begin();
		 iter != m_bucket[hashFunc(key)].end(); ++iter)
	 {
		 HashNode<K, V> tempnode;
		 tempnode.setKey(key);
		 if ((*iter).getKey() == tempnode.getKey())
		 {
			 //cout << (*iter).getKey();
			 HashNode<K, V> tempnode2 = (*iter);
			 iter = m_bucket[hashFunc(key)].erase(iter);
		 }
	 }
 }

 template<typename K, typename V>
 inline void HashTable<K, V>::Traverse(void(*visit)(V value))
 {
	 typename vector<list<HashNode<K, V>>>::iterator iter = m_bucket.begin();
	 for (; iter != m_bucket.end(); ++iter)
	 {
		 for (typename list<HashNode<K, V>>::iterator listIter = (*iter).begin();
			 listIter != (*iter).end(); ++listIter)
		 {
			 if (!(*iter).empty())
				 visit((*listIter).getValue());
		 }
	 }
 }

 template<typename K, typename V>
 inline void HashTable<K, V>::Rehash(int size)
 {
	 vector<list<HashNode<K, V>>> tempbucket;
	 tempbucket.resize(size);
	 typename vector<list<HashNode<K, V>>>::iterator iter = m_bucket.begin();
	 for (; iter != m_bucket.end(); ++iter)
	 {
		 for (typename list<HashNode<K, V>>::iterator listIter = (*iter).begin();
			 listIter != (*iter).end(); ++listIter)
		 {
			 tempbucket[iter] = (*listIter);
		 }
	 }
	 m_bucket = tempbucket;
 }
